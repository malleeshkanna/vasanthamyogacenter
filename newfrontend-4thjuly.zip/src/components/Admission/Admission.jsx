import Breadcrumb from "../../services/Breadcrumb";
import './Admission.css';
import React, { useEffect, useState } from 'react';
import { Formik, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import ValidationsFunc from "../../services/ValidationsFunc";
import { Helmet } from "react-helmet-async";
import ApiService from '../../services/ApiService';
import PageLoader from '../../services/PageLoader';
import ToasterService from '../../services/ToasterService';

export default function Admission() {
    useEffect(()=>{
        scrollTo(0,0)
    },[])

    const [ContactUsLoader,SetContactLoaderState]=useState(false);

    const validationSchema = Yup.object().shape({
        firstname: Yup.string()
            .min(3, 'Firstname must be at least 3 characters')
            .required('Firstname is required'),
        lastname: Yup.string()
            .min(3, 'Lastname must be at least 3 characters')
            .required('Lastname is required'),
        gender: Yup.string()
            .required('Gender is required'),
        whatsapp: Yup.string().min(10, "WhatsApp number must be in 10 digit")
            .required("WhatsApp Number is required"),
        phno: Yup.string().min(10, "Mobile number must be in 10 digit")
            .required("Mobile Number is required"),
        dob: Yup.date()
            .required("Date of Birth is required"),
        age: Yup.number()
            .required("Age is required"),
        address: Yup.string()
            .required("Address is required"),
        interested_in: Yup.string()
            .required("Selection Required"),
        goal: Yup.string(),
    });

    const formValues = {
        firstname: '',
        lastname: '',
        gender: '',
        whatsapp: '',
        phno: '',
        dob: '',
        age: '',
        address: '',
        interested_in: '',
        goal: ''
    }

    async function SubmitAdmission(data){
        SetContactLoaderState(true);
        const res=await ApiService().postMethod('/admission/insert',data);
        SetContactLoaderState(false);
        res.status?ToasterService().notifySuccess(res.message):ToasterService().notifyError(res.message)
    }

    return <div>
        <Breadcrumb img="/breadcrumb/aboutus-bg.webp" menu="Admission" submenu={[{ link: 'Home', route: '/' }, { link: 'Admission', route: '/admission' }]} />
        <Helmet>
            <title>Admission - Vasantham Yoga Center</title>
            <meta name="description" content="Vasantham Yoga Center - Salem, Tamilnadu" />
            <meta name="keywords" content="best yoga center salem,best yoga center,yoga center" />
            <link rel="canonical" href="https://vasanthamyogacenter.com" />
        </Helmet>
        <div className="p-3 p-md-5 container">
            <div className="main-form-container">
                <div className="row">

                    <div className="col-md-6 order-2">
                        <Formik
                            initialValues={formValues}
                            validationSchema={validationSchema}
                            onSubmit={(values, actions) => {
                                SubmitAdmission(values);
                                actions.setSubmitting(false);
                            }}
                        >
                            {(props) => (
                                <form className="p-4" onSubmit={props.handleSubmit}>

                                    <div className="row">
                                        <div className="col-lg-6 ">
                                            <div className="form-floating mb-1">
                                                <Field className="form-control mt-2 mb-2" onInput={(e) => ValidationsFunc().onlyAlphabets(e)} onChange={props.handleChange} onBlur={props.handleBlur} value={props.values.firstname} type="text" name="firstname" id="floatingInput" placeholder="Eg., Karthick" />
                                                <label htmlFor="floatingInput">Firstname</label>
                                            </div>
                                            <ErrorMessage name="firstname" className="text-danger" component="div" />
                                        </div>
                                        <div className="col-lg-6 mt-3 mt-md-0">
                                            <div className="form-floating mb-1">
                                                <Field className="form-control mt-2 mb-2" onInput={(e) => ValidationsFunc().onlyAlphabets(e)} onChange={props.handleChange} onBlur={props.handleBlur} value={props.values.lastname} type="text" name="lastname" id="floatingInput" placeholder="Eg., Mahesh" />
                                                <label htmlFor="floatingInput">Lastname</label>
                                            </div>
                                            <ErrorMessage name="lastname" className="text-danger" component="div" />
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-lg-6 mt-3">
                                            <div className="form-floating">
                                                <Field as="select" className="form-select  mt-2 mb-2" onChange={props.handleChange} value={props.values.gender} id="floatingSelect" name="gender" aria-label="Floating label select example">
                                                    <option value="">--Select--</option>
                                                    <option value="Male">Male</option>
                                                    <option value="Female">Female</option>
                                                </Field>
                                                <label htmlFor="floatingSelect">Gender</label>
                                            </div>
                                            <ErrorMessage name="gender" className="text-danger" component="div" />
                                        </div>
                                        <div className="col-lg-6 mt-3">
                                            <div className="form-floating mb-1">
                                                <Field className="form-control mt-2 mb-2" maxLength="2" onInput={(e) => ValidationsFunc().onlyNumbers(e)} onChange={props.handleChange} onBlur={props.handleBlur} value={props.values.age} type="text" name="age" id="floatingInput" placeholder="Eg., 20" />
                                                <label htmlFor="floatingInput">Age</label>
                                            </div>
                                            <ErrorMessage name="age" className="text-danger" component="div" />
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-lg-6 mt-3">
                                            <div className="form-floating mb-1">
                                                <Field className="form-control mt-2 mb-2" onChange={props.handleChange} value={props.values.dob} type="date" name="dob" id="floatingInput" placeholder="Eg., 13-07-2002" />
                                                <label htmlFor="floatingInput">Date Of Birth</label>
                                            </div>
                                            <ErrorMessage name="dob" className="text-danger" component="div" />
                                        </div>
                                        <div className="col-lg-6 mt-3">
                                            <div className="form-floating mb-1">
                                                <Field className="form-control mt-2 mb-2" maxLength="10" onInput={(e) => ValidationsFunc().onlyNumbers(e)} onChange={props.handleChange} onBlur={props.handleBlur} value={props.values.whatsapp} type="text" name="whatsapp" id="floatingInput" placeholder="Eg., 1234567890" />
                                                <label htmlFor="floatingInput">WhatsApp Number</label>
                                            </div>
                                            <ErrorMessage name="whatsapp" className="text-danger" component="div" />
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-lg-6 mt-3">
                                            <div className="form-floating mb-1">
                                                <Field className="form-control mt-2 mb-2" maxLength="10" onInput={(e) => ValidationsFunc().onlyNumbers(e)} type="text" onChange={props.handleChange} onBlur={props.handleBlur} value={props.values.phno} name="phno" id="floatingInput" placeholder="Eg., 1234567890" />
                                                <label htmlFor="floatingInput">Mobile Number</label>
                                            </div>
                                            <ErrorMessage name="phno" className="text-danger" component="div" />
                                        </div>
                                        <div className="col-lg-6 mt-3">
                                            <div className="form-floating ">
                                                <Field as="select" className="form-select  mt-2 mb-2" id="floatingSelect" onChange={props.handleChange} value={props.values.interested_in} name="interested_in" aria-label="Floating label select example">
                                                    <option value="">--Select--</option>
                                                    <option value="Yoga">Yoga</option>
                                                    <option value="Bharathanatiyam">Bharathanatiyam</option>
                                                    <option value="Drawing">Drawing</option>
                                                </Field>
                                                <label htmlFor="floatingSelect">Interested in</label>
                                            </div>
                                            <ErrorMessage name="interested_in" className="text-danger" component="div" />
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-md-12">
                                            <div className="form-floating mb-1">
                                                <Field as="textarea" className="form-control mt-2 mb-2" onChange={props.handleChange} onBlur={props.handleBlur} value={props.values.goal} type="text" name="goal" id="floatingInput" placeholder="Eg., For Peace" />
                                                <label htmlFor="floatingInput">Tell about your goal (optional)</label>
                                            </div>
                                            <ErrorMessage name="goal" className="text-danger" component="div" />
                                        </div>
                                    </div>
                                    <div className="row">
                                        <div className="col-md-12">
                                            <div className="form-floating mb-1">
                                                <Field as="textarea" className="form-control mt-2 mb-2" type="text" onChange={props.handleChange} onBlur={props.handleBlur} value={props.values.address} name="address" id="floatingInput" placeholder="Eg., Annathanapatti, Salem" />
                                                <label htmlFor="floatingInput">Address</label>
                                            </div>
                                            <ErrorMessage name="address" className="text-danger" component="div" />
                                        </div>
                                    </div>
                                    <div className="d-flex justify-content-center mt-3">
                                        <button type="submit" className='admission-btn'><i className="fa-light fa-check"></i>&nbsp;Submit</button>
                                    </div>
                                </form>
                            )}
                        </Formik>
                    </div>
                    <div className="col-md-6 info-box d-flex align-items-center justify-content-center status-section mt-3 mt-md-0 ">
                        <div className="">
                            <h4 className="text-center field-error fw-bold ">Welcome to Vasantham Yoga Center</h4>
                            <div className="d-flex justify-content-center">
                            <img src="/common/vyc-logo.png" alt="" width="220" height="150" />
                            </div>
                            <p className="text-white text-center mt-4 ">Applying for admission to Vasantham Yoga Center is simple and straightforward. Our diverse classes cater to all skill levels, ensuring a fit for everyone. Complete the online application form and choose your preferred class schedule. Our team will review your application and get in touch promptly. Join us to embark on a journey of wellness and self-discovery.</p>
                        </div>

                    </div>
                </div>
            </div>

        </div>
        <PageLoader text="Submitting" visibility={ContactUsLoader}/>
    </div>
}