import { Grid } from "react-loader-spinner";
const PageLoader = ({ visibility }) => {
    return (
        <div>
            {visibility && (
                <div className="pageloader">
                    <div className="pageloader-content">
                        <div>
                            <Grid
                                visible={true}
                                height="80"
                                width="80"
                                color="#4fa94d"
                                ariaLabel="grid-loading"
                                radius="12.5"
                                wrapperStyle={{}}
                                wrapperClass="grid-wrapper"
                            />
                            <h5 className="mt-2">Loading...</h5>
                        </div>

                    </div>
                </div>
            )}
        </div>
    );
};

export default PageLoader;
