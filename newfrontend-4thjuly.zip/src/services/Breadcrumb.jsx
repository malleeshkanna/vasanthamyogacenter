import { Link } from 'react-router-dom';

export default function Breadcrumb({ img, menu, submenu }) {
    return (
        <div className="breadcrumb-container">
            <img src={img} alt="Breadcrumb Background" className="image"></img>
            <h3 className="text">{menu}</h3>
            <div>
                {submenu.map((menu, index) => (
                    <span key={index}>
                        <Link to={menu.route}>&nbsp;{menu.link?.length>20?menu.link.slice(0,20)+"...":menu.link} </Link>{submenu.length==index+1?'':'/'}
                    </span>

                ))}
            </div>
        </div>
    )
}