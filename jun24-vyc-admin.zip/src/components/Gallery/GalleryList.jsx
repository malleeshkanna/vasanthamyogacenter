import './Gallery.css';
import { useEffect, useState } from 'react';
import ApiService from '../../Services/ApiService';
import ToasterService from '../../Services/ToasterService';
import PageLoder from '../../Services/PageLoder';

export default function GalleryList() {
    const [galleryImages, SetGalleryImages] = useState([]);
    const [galleryId, SetGalleryId] = useState(null);
    const [LoaderState, SetLoaderState] = useState(false);

    useEffect(() => {
        callGalleryAPI();
    }, [])

    async function callGalleryAPI() {
        SetLoaderState(true)
        const res = await ApiService().getMethod('/gallery/showAll?page=1');
        console.log(res)
        SetLoaderState(false)
        if (res.status == false) {
            ToasterService().notifyError(res.message)
        } else {
            SetGalleryImages(res.data)
        }
    }

    async function deleteGallery(data) {
        SetLoaderState(true)
        const res = await ApiService().postMethod('/gallery/delete', {
            id: data.id, imgurl: data.imgurl
        });
        console.log(res)
        SetLoaderState(false)
        if (res.status) {
            callGalleryAPI();
            ToasterService().notifySuccess(res.message)
        } else {
            ToasterService().notifyError(res.message)
        }
    }
    return (
        <div className='gallery-form-container p-4 mt-4'>
            <h3 className='text-center'>Edit Gallery</h3>
            <div className='photo-container mt-3 p-3'>
                <div className="row">
                    {galleryImages.length != 0 ?
                        galleryImages.map((gallery, i) => (
                            <div className="col-md-4 mt-3" key={i}>
                                <div className="p-3 gallery-imgs ">
                                    <img src={ApiService().getImages("gallery/" + gallery.imgurl)} alt="" />
                                    <div className="row mt-3">
                                        <div className="col-12">
                                            <button data-bs-toggle="modal" data-bs-target="#DeleteConfirmDialog" onClick={() => SetGalleryId(gallery)} className="btn btn-danger w-100"><i class="fa-regular fa-trash"></i>&nbsp;Delete</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )) :
                        <>
                            <h1 className='text-center'>
                                <i className="fa-solid fa-file-slash"></i>
                            </h1>
                            <h3 className='text-center mt-3'>No Data Available</h3>
                        </>
                    }
                </div>
            </div>
            {/* <Modal */}
            <div class="modal fade" id="DeleteConfirmDialog" tabindex="-1" aria-labelledby="DeleteConfirmDialogLabel" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="DeleteConfirmDialogLabel">Confirmation</h5>
                        </div>
                        <div class="modal-body">
                            Are you sure want to delete ?
                        </div>
                        <div class="modal-footer">
                            <button type="button" data-bs-dismiss="modal" onClick={() => deleteGallery(galleryId)} class="btn btn-danger">Yes</button>
                            <button type="button" class="btn btn-primary" data-bs-dismiss="modal">No</button>
                        </div>
                    </div>
                </div>
            </div>
            <PageLoder text="Deleting" visibility={LoaderState} />
        </div>
    )
}