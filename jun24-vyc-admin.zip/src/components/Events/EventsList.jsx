import './Events.css';
import { useEffect, useState } from 'react';
import ApiService from '../../Services/ApiService';
import ToasterService from '../../Services/ToasterService';
import PageLoder from '../../Services/PageLoder';

export default function EventsList(){
    const [EventsData, SetEvents] = useState([]);
    const [EventId, SetEventId] = useState(null);
    const [EventLoaderState, SetEventLoaderState] = useState(false);

    useEffect(() => {
        callGalleryAPI();
    }, [])

    async function callGalleryAPI() {
        SetEventLoaderState(true)
        const res = await ApiService().getMethod('/events/showAll?page=1');
        console.log(res)
        SetEventLoaderState(false)
        if (res.status == false) {
            ToasterService().notifyError(res.message)
        } else {
            SetEvents(res.data)
        }
    }
}