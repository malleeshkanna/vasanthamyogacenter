import axios from "axios";

export default function ApiService() {
    const baseurl = "http://192.168.29.21/vasanthamyogacenter/public";

    async function generateCSRF() {
        const response = await axios.get(baseurl + '/csrf-token');
        return response.data.csrfToken;
    }

    return {
        postMethod: async (url, formData) => {
            try {
                const csrfToken = await generateCSRF();
                const response = await axios.post(baseurl + url, formData, {
                    headers: {
                        'Content-Type': 'multipart/form-data',
                        'X-CSRF-TOKEN': csrfToken
                    }
                });
                return response.data;
            } catch (error) {
                return error;
            }
        },
        getMethod: async (url) => {
            try {
                const response = await axios.get(baseurl + url);
                return response.data;
            } catch (error) {
                return error;
            }
        },
        getImages:(url)=>{
            return baseurl+"/storage/"+url
        }
    }
}
