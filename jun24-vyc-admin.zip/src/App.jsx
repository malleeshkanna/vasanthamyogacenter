import { Suspense, lazy } from 'react';
import { Routes, Route } from 'react-router-dom';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.min.js';
import 'react-toastify/dist/ReactToastify.css';
import { ToastContainer } from 'react-toastify';

import PageLoader from './Services/PageLoder';
import SideNavigation from './components/SideNavigation/SideNavigation';

const Gallery = lazy(() => import('./components/Gallery/Gallery'));
const Events = lazy(() => import('./components/Events/Events'));

function App() {

  return (
    <>
      <SideNavigation />
      <Suspense fallback={<PageLoader visibility={true} text="Loading" />}>
        <Routes>
          <Route path='/gallery' element={<Gallery />} />
          <Route path='/events' element={<Events />} />
        </Routes>
      </Suspense>
      <ToastContainer/>
    </>

  )
}

export default App
