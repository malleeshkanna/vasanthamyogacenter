import './Admissions.css';
import PageLoder from '../../Services/PageLoder';
import ApiService from '../../Services/ApiService';
import { useEffect, useState } from 'react';
import ToasterService from '../../Services/ToasterService';

export default function Admissions() {
    const [AdmissionLoader, SetAdmissionLoader] = useState(false);
    const [AdmissionData, SetAdmissionData] = useState([]);
    const [LastPage, SetLastPage] = useState(1);
    const [currentPage, SetCurrentPage] = useState(1);
    const [TotalCount, SetTotalCount] = useState(0);
    const [AdmissionTempData, SetAdmissionTempData] = useState([]);
    useEffect(() => {
        initQueries(currentPage);
    }, [])

    async function initQueries(pgno) {
        SetAdmissionLoader(true);
        const res = await ApiService().postMethod('/admission/get?page=' + pgno);
        console.log(res);
        SetAdmissionData(res.data.data)
        SetAdmissionLoader(false);
        SetLastPage(res.data.last_page);
        SetCurrentPage(res.data.current_page);
        SetTotalCount(res.data.total)
    }

    function paginate(pgno) {
        SetCurrentPage(pgno);
        initQueries(pgno);
    }

    async function DeleteAdmissionData() {
        const res = await ApiService().postMethod('/admission/delete', { id: AdmissionTempData.id });
        if (res.status) {
            ToasterService().notifySuccess(res.message);
            initQueries();
        } else {
            ToasterService().notifyError(res.message);
        }
    }

    return (
        <>
            <div className="container mt-4">
                <h3 className='text-center'>Admission Queries</h3>
                <div className="contactus-container p-4 mt-4">
                    <div className="row">
                        {AdmissionData.length != 0 ?
                            AdmissionData.map((data, i) => (
                                <div className="col-md-4 mt-3" key={i}>
                                    <div className='query-card p-3'>
                                        <h4>{data.firstname} {data.lastname}</h4>
                                        <h5>Interested In : {data.interested_in}</h5>
                                        <i className="fa-regular fa-phone"></i>&nbsp;<a href={"tel://" + data.phno}>{data.phno}</a>
                                        {/* <h6 className='mt-2'>{data.message?.length < 20 ? data.message : data.message.slice(0, 20) + "..."}</h6> */}
                                        <div className="row mt-3">
                                            <div className="col-6">
                                                <button data-bs-toggle="modal" onClick={() => SetAdmissionTempData(data)} data-bs-target="#deleteContactConfirm" className="btn btn-primary w-100"><i className='fa fa-edit'></i>&nbsp;&nbsp;Edit</button>
                                            </div>
                                            <div className="col-6">
                                                <button data-bs-toggle="modal" onClick={() => SetAdmissionTempData(data)} data-bs-target="#deleteContactConfirm" className="btn btn-danger w-100"><i className='fa fa-trash'></i>&nbsp;&nbsp;Delete</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )) :
                            <>
                                <h1 className='text-center'>
                                    <i className="fa-solid fa-file-slash"></i>
                                </h1>
                                <h3 className='text-center mt-3'>No Data Available</h3>
                            </>
                        }

                    </div>
                </div>
                {TotalCount > 10 ?
                    <div className="d-flex justify-content-between mt-3 ">
                        <div>
                            <button className='submit-btn' disabled={currentPage == 1} onClick={() => { paginate(currentPage - 1) }} ><i className="fa-solid fa-chevrons-left"></i>&nbsp;Prev</button>
                        </div>
                        <div>
                            <button className='submit-btn' disabled={currentPage == LastPage} onClick={() => { paginate(currentPage + 1) }} >Next&nbsp;<i className="fa-solid fa-chevrons-right"></i></button>
                        </div>
                    </div> : null
                }

            </div>
            <div className="modal fade" id="deleteContactConfirm" tabIndex="-1" aria-labelledby="deleteContactConfirmLabel" aria-hidden="true">
                <div className="modal-dialog  modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="deleteContactConfirmLabel">Delete Confirmation</h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div className="modal-body">
                            Are you sure want to delete ?
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-success" onClick={() => DeleteAdmissionData()} data-bs-dismiss="modal">Yes</button>
                            <button type="button" className="btn btn-danger" data-bs-dismiss="modal">No</button>
                        </div>
                    </div>
                </div>
            </div>
            <PageLoder text="Loading" visibility={AdmissionLoader} />
        </>

    )
}