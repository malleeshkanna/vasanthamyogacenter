import './Contacts.css';
import PageLoder from '../../Services/PageLoder';
import ApiService from '../../Services/ApiService';
import { useEffect, useState } from 'react';
import ToasterService from '../../Services/ToasterService';

export default function Contacts() {
    const [contactUsLoader, SetContactsUsLoader] = useState(false);
    const [ContactsData, SetContactsData] = useState([]);
    const [LastPage, SetLastPage] = useState(1);
    const [currentPage, SetCurrentPage] = useState(1);
    const [contactUsTempData, SetcontactUsTempData] = useState([]);
    const [TotalCount, SetTotalCount] = useState(0);

    useEffect(() => {
        initQueries(currentPage);
    }, [])



    async function initQueries(pgno) {
        SetContactsUsLoader(true);
        const res = await ApiService().postMethod('/contact/get?page=' + pgno);
        SetContactsData(res.data.data)
        SetContactsUsLoader(false);
        SetLastPage(res.data.last_page);
        SetCurrentPage(res.data.current_page)
        SetTotalCount(res.data.total)
    }

    function paginate(pgno) {
        SetCurrentPage(pgno);
        initQueries(pgno);
    }

    async function DeleteContactData() {
        const res = await ApiService().postMethod('/contact/delete', { id: contactUsTempData.id });
        if (res.status) {
            ToasterService().notifySuccess(res.message);
            initQueries();
        } else {
            ToasterService().notifyError(res.message);
        }
    }

    return (
        <>
            <div className="container mt-4">
                <h3 className='text-center'>Contact Queries</h3>
                <div className="contactus-container p-4 mt-4">
                    <div className="row">
                        {ContactsData.length != 0 ?
                            ContactsData.map((data, i) => (
                                <div className="col-md-4 mt-3" key={i}>
                                    <div className='query-card p-3'>
                                        <h4>{data.firstname} {data.lastname}</h4>
                                        {data.email != null ? <a href={"mailto:" + data.email}> {data.email} | </a> : null}
                                        <a href={"tel://" + data.phno}>{data.phno}</a>
                                        <h6 className='mt-2'>{data.message?.length < 20 ? data.message : data.message.slice(0, 20) + "..."}</h6>
                                        <div className="row mt-3">
                                            <div className="col-12">
                                                <button data-bs-toggle="modal" onClick={() => SetcontactUsTempData(data)} data-bs-target="#deleteContactConfirm" className="btn btn-danger w-100"><i className='fa fa-trash'></i>&nbsp;&nbsp;Delete</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )) :
                            <>
                                <h1 className='text-center'>
                                    <i className="fa-solid fa-file-slash"></i>
                                </h1>
                                <h3 className='text-center mt-3'>No Data Available</h3>
                            </>
                        }

                    </div>
                </div>
                {TotalCount > 10 ?
                    <div className="d-flex justify-content-between mt-3 ">
                        <div>
                            <button className='submit-btn' disabled={currentPage == 1} onClick={() => { paginate(currentPage - 1) }} ><i className="fa-solid fa-chevrons-left"></i>&nbsp;Prev</button>
                        </div>
                        <div>
                            <button className='submit-btn' disabled={currentPage == LastPage} onClick={() => { paginate(currentPage + 1) }} >Next&nbsp;<i className="fa-solid fa-chevrons-right"></i></button>
                        </div>
                    </div> : null
                }

            </div>
            <div className="modal fade" id="deleteContactConfirm" tabIndex="-1" aria-labelledby="deleteContactConfirmLabel" aria-hidden="true">
                <div className="modal-dialog  modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="deleteContactConfirmLabel">Delete Confirmation</h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div className="modal-body">
                            Are you sure want to delete ?
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-success" onClick={() => DeleteContactData()} data-bs-dismiss="modal">Yes</button>
                            <button type="button" className="btn btn-danger" data-bs-dismiss="modal">No</button>
                        </div>
                    </div>
                </div>
            </div>
            <PageLoder text="Loading" visibility={contactUsLoader} />
        </>

    )
}