import { IgrNavDrawerModule, IgrNavDrawer, IgrNavDrawerHeaderItem, IgrNavDrawerItem } from 'igniteui-react';
import 'igniteui-webcomponents/themes/light/bootstrap.css';
import './SideNavigation.css';
import { useState, useEffect, useRef } from 'react';
IgrNavDrawerModule.register();
import { Link, NavLink } from 'react-router-dom'

export default function SideNavigation() {
    const navBarData = [
        { name: 'Dashboard', icon: 'fa-regular fa-gauge-max', route: '/dashboard' },
        { name: 'Gallery', icon: 'fa-regular fa-rectangle-history-circle-plus', route: '/gallery' },
        { name: 'Events', icon: 'fa-regular fa-calendar', route: '/events' },
        { name: 'Announcements', icon: 'fa-regular fa-megaphone', route: '/announcements' },
        { name: 'Testimonials', icon: 'fa-regular fa-star', route: '/testimonials' },
        { name: 'Contact Queries', icon: 'fa-regular fa-phone', route: '/contact-queries' },
        { name: 'Admissions', icon: 'fa-regular fa-note', route: '/admissions' },
        { name: 'Create Forms', icon: 'fa-regular fa-notes', route: '' },
        { name: 'Form Response', icon: 'fa-regular fa-file-magnifying-glass', route: '' },
    ]
    const [sideBarState, SetSideBarState] = useState(false);
    const drawerRef = useRef(null);

    return (
        <>
            <IgrNavDrawer open={sideBarState} ref={drawerRef}>
                <div className="logo-section" key="logo-section">
                    <img src="/vyc-logo.png" width="150" height="100" alt="" />
                </div>
                <div className="menu-container" key="menu-container">
                    <div className='p-4'>
                        {navBarData.map((data,i) => (
                            <div className='menu-section p-2' key={i}>
                                <div className='d-flex'>
                                    <i className={data.icon + " mt-1"}></i>
                                    <h6 className='ms-3'><Link to={data.route}>{data.name}</Link></h6>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </IgrNavDrawer>
            <nav>
                <div className="row">
                    <div className="col-2 col-md-4">
                        <button onClick={() => SetSideBarState(!sideBarState)} className='btn'><i className="fa-solid fa-bars"></i></button>

                    </div>
                    <div className="col-10 col-md-8">
                        <h5 className=' mt-1'>Vasantham Yoga Center - Admin</h5>
                    </div>
                </div>
            </nav>
        </>
    )
}