import './Events.css';
import { Formik, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';

export default function Events(){
    return <h1>Gallery</h1>
}