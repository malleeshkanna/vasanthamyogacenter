import './Testimonials.css';
import { Formik, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import ToasterService from '../../Services/ToasterService';
import ApiService from '../../Services/ApiService';
import PageLoder from '../../Services/PageLoder';
import { useState } from 'react';
import TestimonialsList from './TestimonialsList';

export default function Testimonials() {

    const [submitBtn, setSubmitBtn] = useState(false);

    const validationSchema = Yup.object().shape({
        name: Yup.string()
            .min(3, 'Name must be at least 3 characters')
            .required('Name is required'),
        ratings: Yup.string().required("Rating is Required"),
        message: Yup.string()
            .min(3, 'Message must be at least 3 characters')
            .required("Message is Required"),
    });

    async function submitTestimonial(data) {
        setSubmitBtn(true);
        data.ratings=Number(data.ratings)
        const res = await ApiService().postMethod('/testimonials/insert', data);
        setSubmitBtn(false);
        if (res.status) {
            ToasterService().notifySuccess(res.message);
            window.location.reload();
        } else {
            ToasterService().notifyWarning(res.message)
        }
    }

    const formValues = {
        name: '',
        ratings: '1',
        message: '',
    }

    return (
        <div className="container mt-4">
            <h3 className='text-center'>Add Testimonials</h3>
            <div className="announcement-form-container p-4 mt-4">
                <Formik
                    initialValues={formValues}
                    validationSchema={validationSchema}
                    onSubmit={(values, actions) => {
                        submitTestimonial(values);
                        actions.setSubmitting(false);
                    }}
                >
                    {({ handleSubmit, setFieldValue, handleChange, handleBlur, values }) => (
                        <form onSubmit={handleSubmit}>
                            <div className="row">
                                <div className="col-lg-4">
                                    <div className="form-floating mb-1">
                                        <Field className="form-control mt-2 mb-2" onChange={handleChange} onBlur={handleBlur} value={values.name} type="text" name="name" id="floatingInput" placeholder="Eg., Yoga Day" />
                                        <label htmlFor="floatingInput">Name</label>
                                    </div>
                                    <ErrorMessage name="name" className="text-danger" component="div" />
                                </div>
                                <div className="col-lg-4">
                                    <div className="form-floating mb-1">
                                        <Field className="form-control mt-2 mb-2" min='0' max="5" onChange={handleChange} onBlur={handleBlur} value={values.ratings} type="range" name="ratings" id="floatingInput" placeholder="Eg.," />
                                        <label htmlFor="floatingInput">Ratings</label>
                                    </div>
                                    <ErrorMessage name="ratings" className="text-danger" component="div" />
                                </div>
                                <div className="col-lg-4">
                                    <div className="form-floating mb-1">
                                        <Field as="textarea" className="form-control mt-2 mb-2" onChange={handleChange} onBlur={handleBlur} value={values.message} name="message" id="floatingInput" placeholder="Eg., Lorem Ipsum." />
                                        <label htmlFor="floatingInput">Message</label>
                                    </div>
                                    <ErrorMessage name="message" className="text-danger" component="div" />
                                </div>
                            </div>
                            <div className="d-flex justify-content-center mt-3">
                                <input type="submit" disabled={submitBtn} className="btn btn-success" value="Submit" />
                            </div>
                        </form>
                    )}
                </Formik>
            </div>
            <TestimonialsList />
            <PageLoder text={'Adding'} visibility={submitBtn} />
        </div>
    )
}