import './Contacts.css';
import PageLoder from '../../Services/PageLoder';
import ApiService from '../../Services/ApiService';
import { useEffect, useState } from 'react';

export default function Contacts() {
    const [contactUsLoader, SetContactsUsLoader] = useState(false);
    const [ContactsData, SetContactsData] = useState([]);
    const [LastPage, SetLastPage] = useState(1);
    const [currentPage, SetCurrentPage] = useState(1);

    useEffect(() => {
        initQueries();
    }, [])

    async function initQueries() {
        SetContactsUsLoader(true);
        const res = await ApiService().postMethod('/contact/get');
        SetContactsData(res.data.data)
        SetContactsUsLoader(false);
        console.log(res.data.data);
    }
    return (
        <>
            <div className="container mt-4">
                <h3 className='text-center'>Contact Queries</h3>
                <div className="contactus-container p-4 mt-4">
                    <div className="row">
                        {ContactsData.map((data) => (
                            <div className="col-md-4">
                                <div className='query-card p-3'>
                                    <h4>{data.firstname} {data.lastname}</h4>
                                    {data.email != null ? <a href={"mailto:"+data.email}> {data.email} | </a> : null}
                                    <a href={"tel://"+data.phno}>{data.phno}</a>
                                    <h6 className='mt-2'>{data.message?.length<20?data.message:data.message.slice(0,20)+"..."}</h6>
                                    <div className="row mt-3">
                                        <div className="col-6">
                                            <button className="btn btn-primary w-100">View</button>
                                        </div>
                                        <div className="col-6">
                                            <button className="btn btn-danger w-100">Delete</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
            <PageLoder text="Loading" visibility={contactUsLoader} />
        </>

    )
}