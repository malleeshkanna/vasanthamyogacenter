import { ToastContainer, toast } from 'react-toastify';

export default function ToasterService(){
    return{
        notifySuccess : (msg) => toast.success(msg),
        notifyWarning : (msg) => toast.warn(msg),
        notifyError : (msg) => toast.error(msg),
    }
}