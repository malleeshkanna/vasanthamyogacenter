import { Suspense, lazy } from 'react';
import { Routes, Route } from 'react-router-dom';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.min.js';
import 'react-toastify/dist/ReactToastify.css';
import { ToastContainer } from 'react-toastify';

import PageLoader from './Services/PageLoder';
import SideNavigation from './components/SideNavigation/SideNavigation';

const Gallery = lazy(() => import('./components/Gallery/Gallery'));
const Events = lazy(() => import('./components/Events/Events'));
const Announcements = lazy(() => import('./components/Announcements/Announcements'));
const Testimonials = lazy(() => import('./components/Testimonials/Testimonials'));
const Contacts = lazy(() => import('./components/Contacts/Contacts'));

function App() {

  return (
    <>
      <SideNavigation />
      <Suspense fallback={<PageLoader visibility={true} text="Loading" />}>
        <Routes>
          <Route path='/gallery' element={<Gallery />} />
          <Route path='/events' element={<Events />} />
          <Route path='/announcements' element={<Announcements />} />
          <Route path='/announcements' element={<Announcements />} />
          <Route path='/testimonials' element={<Testimonials />} />
          <Route path='/contact-queries' element={<Contacts />} />
        </Routes>
      </Suspense>
      <ToastContainer/>
    </>

  )
}

export default App
