import { useState } from "react"
import CustFormatters from "../../services/CustFormatters";
import {CBadge} from '@coreui/react'

export default function MainNewsArea() {
    const [mainNews, setMainNews] = useState({
        heading: "Some new based on Yoga Center",
        date: '2024-06-21', newslink: 'my-news-link', newsimg: '../sample/sample-news.jpg',
        content: 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque praesentium, reiciendis tempore blanditiis consectetur quas! Id ex doloremque veniam pariatur ipsum, minima nihil sint provident ea, perferendis labore praesentium illum molestias a. Obcaecati rem saepe, nam esse voluptatum ab dolore amet. Iusto, quia corrupti sunt esse laborum doloremque sit ipsa eaque dolorum a ullam, nisi quaerat itaque voluptas. Necessitatibus facere fuga, aut dicta consectetur nostrum consequatur, molestias voluptatibus adipisci, porro reprehenderit. Rem delectus, a vero ullam deleniti, iure accusantium et ratione quo odio nesciunt dicta facere itaque! Non saepe unde aliquam excepturi est expedita laborum quis eveniet mollitia repellendus rerum, incidunt ipsum, id eos vitae assumenda deserunt. Ipsa odio ratione aliquid facere quo laudantium necessitatibus aperiam commodi quos facilis, cumque non, tempora recusandae beatae ut rerum nemo cupiditate! Id odio quas non asperiores iure dolorem sunt recusandae numquam velit? Laudantium, delectus eveniet perferendis animi asperiores ratione esse! Ea quae consequatur dolore. Ut beatae maxime maiores consequuntur deleniti velit inventore, voluptates similique totam illo delectus aspernatur autem ratione quidem, sequi voluptatibus recusandae vitae amet molestias sint nobis deserunt. Officiis quo eveniet provident, nisi nostrum iste eaque vel ad dolore fuga vitae alias aliquam accusamus distinctio quidem voluptatibus ipsa eius, quae omnis.'
    });
    return (
        <div className="main-area-content">
            <h3 className="new-heading">{mainNews.heading}</h3>
            <div>
                <div>
                    <span className="details-color mt-1"><i className="fa-light fa-calendar"></i> &nbsp; {CustFormatters().dateFormatter(mainNews.date)}</span>
                    &nbsp;&nbsp;&nbsp;| &nbsp;&nbsp;<i className="fa-light fa-location-dot"></i>&nbsp; Salem &nbsp;&nbsp;&nbsp;| &nbsp;&nbsp;<a href=''><CBadge color="success"><i className="fa-brands fa-whatsapp"></i>&nbsp;Share on WhatsApp</CBadge> </a>
                </div>
            </div>
            <div className="mt-3">
                <img src={mainNews.newsimg} className="news-img" alt="" />
                <p className="news-content mt-3">{mainNews.content}</p>
            </div>
            <div className="d-flex justify-content-between ">
                <div>
                    <button className='admission-btn'><i className="fa-solid fa-chevrons-left"></i>&nbsp;Prev</button>
                </div>
                <div>
                    <button className='admission-btn'>Next&nbsp;<i className="fa-solid fa-chevrons-right"></i></button>
                </div>
            </div>
        </div>
    )
}