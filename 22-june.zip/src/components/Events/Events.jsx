import Breadcrumb from "../../services/Breadcrumb";
import MainNewsArea from "./MainNewsArea";
import RecentNewsArea from "./RecentNewsArea";
import './Events.css'
import { Helmet } from "react-helmet-async";

export default function Events() {
    return (
        <div>
            <Breadcrumb img="/breadcrumb/events-bg.jpg" menu="Events" submenu={[{ link: 'Home', route: '/' }, { link: 'Events', route: '/events/0' }]} />
            <Helmet>
                <title>Events - Vasantham Yoga Center</title>
                <meta name="description" content="Vasantham Yoga Center - Salem, Tamilnadu" />
                <meta name="keywords" content="best yoga center salem,best yoga center,yoga center" />
                <link rel="canonical" href="https://vasanthamyogacenter.com/home" />
            </Helmet>
            <div className="p-3">
                <div className="container">
                    <div className="row">
                        <div className="col-md-8">
                            <MainNewsArea />
                        </div>
                        <div className="col-md-4">
                            <RecentNewsArea />
                        </div>
                    </div>
                </div>

            </div>
        </div>

    )
}

