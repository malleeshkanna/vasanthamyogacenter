import Breadcrumb from "../../services/Breadcrumb";
import './Aboutus.css';

export default function Aboutus() {
    return <div>
        <Breadcrumb img="/breadcrumb/aboutus-bg.webp" menu="About Us" submenu={[{ link: 'Home', route: '/' }, { link: 'About us', route: '/aboutus' }]} />
        <div className="aboutus-section">
            <div className="p-3">
                <p className="text-justify">
                    Welcome to <b>Vasantham Yoga Center</b>, where the ancient art of yoga is revitalized for the modern world. Founded by Mr. Vishnu Bairavan, our center is dedicated to fostering physical health, mental clarity, and spiritual growth through comprehensive yoga training and practice.
                </p>
                <h3 className="text-center" >Our Mission</h3>
                <p className="text-justify">
                    At Vasantham Yoga Center, our mission is to promote holistic wellness through the practice of yoga. We believe in the transformative power of yoga to improve physical health, mental clarity, and emotional balance. Our goal is to make yoga accessible to everyone, regardless of age, fitness level, or experience.
                </p>
                <h3 className="text-center">Meet Our Founder - Mr. Vishnu Bairavan</h3>
                <div className="container-fluid mt-4">
                    <div className="row">
                        <div className="col-md-4 d-flex align-items-center justify-content-center mt-3 mt-md-0 ">
                            <img src="/aboutus/founder-of-vyc.webp" className="founder-profile" alt="Mr. Vishnu Bairavan" />
                        </div>
                        <div className="col-md-8 mt-3 mt-md-0">
                            <p>Mr. Vishnu Bairavan, affectionately known as Mr. Yoga, is the heart and soul of Vasantham Yoga Center. With an impressive educational background, including a B.Com., B.Sc., M.Com., and M.A. in Yoga, he brings a wealth of knowledge and experience to our community.</p>
                            <p>Mr. Bairavan's journey in yoga spans over a decade, during which he has taught in various educational institutions, including CBSE schools, matriculation schools, and university colleges. His expertise and dedication have earned him numerous accolades, including:</p>
                            <ul className="bullet-list">
                                <li>16 world record achievements</li>
                                <li>Over 80 competition victories</li>
                                <li>Recognition as a gold medalist</li>
                                <li>The honor of training more than 500 students daily</li>
                            </ul>
                            <p>His passion for yoga is evident in his teaching style, which focuses on advanced yoga asanas and holistic health practices.</p>
                        </div>
                    </div>
                </div>
                <h3 className="text-center">Our Achievements</h3>
                <p>Vasantham Yoga Center takes pride in the numerous achievements and recognitions of our founder and students. We have a legacy of excellence that includes:</p>

                <div className="row">
                    <div className="col-lg-4 d-flex align-items-stretch col-md-6 mt-3 mt-md-0">
                        <div className="achivement-card">
                            <p>
                                Training sessions for state, national, and international level competitions
                            </p>
                            <div className="d-flex justify-content-center">
                                <img src="/logos/international.png" alt="" />

                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 d-flex align-items-stretch col-md-6 mt-3 mt-md-0">
                        <div className="achivement-card">
                            <p>Participation in Khelo India and various other prestigious events
                            </p>
                            <div className="d-flex justify-content-center">
                                <img src="/logos/khelo-india.png" alt="" />

                            </div>
                        </div>
                    </div>
                    <div className="col-lg-4 d-flex align-items-stretch col-md-6 mt-3 mt-md-0">
                        <div className="achivement-card">
                            <p>Producing yoga champions who have earned titles such as Yoga Nakshatra, Yoga Kalachelvan, and Yoga Ratna
                            </p>
                            <div className="d-flex justify-content-center">
                                <img src="/logos/prize-cup.png" alt="" />

                            </div>
                        </div>
                    </div>
                </div>

                <div className="mt-5">
                    <h3 className="text-center">Our Offerings</h3>
                    <div className="row">
                        <div className="col-md-6">
                            <p>We offer a diverse range of yoga classes and workshops tailored to meet the needs of our students. Whether you are a beginner or an advanced practitioner, our programs are designed to help you achieve your personal health and wellness goals.</p>

                        </div>
                        <div className="col-md-6">
                            <p>Join us at Vasantham Yoga Center and embark on a journey of self-discovery and transformation through the practice of yoga. Let us guide you towards a healthier, happier, and more balanced life.</p>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
}