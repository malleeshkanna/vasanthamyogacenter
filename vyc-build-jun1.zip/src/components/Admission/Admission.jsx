export default function Admission(){
    return
}