import { useEffect, useState } from 'react';
import './Form.css';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import PageLoader from '../services/PageLoader';
import {  toast } from 'react-toastify';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';

export default function FormHome() {
    const { id } = useParams();
    const [pageLoader, SetPageLoader] = useState(false);
    const [formFields, SetFormFields] = useState([]);
    const [OtherResp,SetOtherResp] = useState([]);
    const navigate=useNavigate();

    const baseUrl = "http://192.168.29.21/vasanthamyogacenter/public";

    useEffect(() => {
        initForm();
    }, [])

    async function initForm() {
        SetPageLoader(true);
        const res = await axios.post(baseUrl + "/forms/get-form", { link: id });
        SetPageLoader(false);
        if (res.data.status) {
            SetFormFields(JSON.parse(res.data.data.formdata))
            SetOtherResp(res.data.data)
        } else {
            toast.error(res.message)
        }
    }

    async function SubmitFormResponse(values){
        console.log(values);
        const formObj={
            formresponse:JSON.stringify(values),
            link:id
        }
        SetPageLoader(true);
        const res=await axios.post(baseUrl+"/forms/submit-form-response",formObj);
        SetPageLoader(false);
        console.log(res);
        if (res.data.status) {
            toast.success(res.message);
            navigate('/success')
        } else {
            toast.error(res.message)
        }
    }

    const generateValidationSchema = (fields) => {
        const shape = {};
        fields.forEach(field => {
            let schema;
            if (field.type === 'checkbox') {
                schema = Yup.array().of(Yup.string());
                if (field.validation.required) {
                    schema = schema.min(1, 'Required');
                }
            } else {
                schema = Yup.string();
                if (field.type === 'number') {
                    schema = Yup.number();
                }
                if (field.validation.required) {
                    schema = schema.required(field.label+' is Required');
                }
                if (field.validation.min) {
                    schema = schema.min(field.validation.min, `Must be at least ${field.validation.min}`);
                }
                // if (field.validation.max) {
                //     schema = schema.max(field.validation.max, `Must be less than ${field.validation.max}`);
                // }
                if (field.validation.email) {
                    schema = schema.email('Invalid email address');
                }
            }
            shape[field.name] = schema;
        });
        return Yup.object().shape(shape);
    };

    const initialValues = {};
    formFields.forEach(field => {
        if (field.type === 'checkbox') {
            initialValues[field.name] = [];
        } else {
            initialValues[field.name] = '';
        }
    });

    function validateNumberInput(e) {
        // Remove any non-numeric characters
        e.target.value = e.target.value.replace(/[^0-9]/g, '');
    }

    const validationSchema = generateValidationSchema(formFields);

    return (
        <div className=''>
            <div className="container">
                <div className="d-flex justify-content-center pt-3">
                    <img src="./header-img.png" className='img-fluid' alt="" />
                </div>
                <div className="forms-container mt-3 p-3">
                    <Formik
                        initialValues={initialValues}
                        validationSchema={validationSchema}
                        onSubmit={values => {
                            SubmitFormResponse(values)
                        }}
                    >
                        <Form className=''>
                            <div className="container mt-4">
                                <h4 className='text-center'>{OtherResp.formname}</h4>
                                <p className='text-center'>{OtherResp.description}</p>
                                <div className="row form-fields-bg">
                                    {formFields.map(field => (
                                        <div className='col-lg-4 col-md-6 mt-4' key={field.name}>
                                            {field.type === 'text' && (
                                                <div className="form-floating mb-1">
                                                    <Field className="form-control mt-2 mb-2" maxLength={field.validation.max} name={field.name} type="text" id="floatingInput" placeholder="Eg.,John Doe" />
                                                    <label htmlFor="floatingInput">{field.label}</label>
                                                </div>
                                                // <Field className="form-control" name={field.name} type="text" />
                                            )}
                                            {field.type === 'number' && (
                                                <div className="form-floating mb-1">
                                                    <Field className="form-control mt-2 mb-2" maxLength={field.validation.max} onInput={(e) => validateNumberInput(e)} name={field.name} type="text" id="floatingInput" placeholder="Eg.,John Doe" />
                                                    <label htmlFor="floatingInput">{field.label}</label>
                                                </div>
                                                // <Field className="form-control" name={field.name} type="text" />
                                            )}
                                            {field.type === 'textarea' && (
                                                <div className="form-floating mb-1">
                                                    <Field className="form-control mt-2 mb-2" maxLength={field.validation.max} name={field.name} as="textarea" id="floatingInput" placeholder="Eg.,John Doe" />
                                                    <label htmlFor="floatingInput">{field.label}</label>
                                                </div>
                                            )}
                                            {field.type === 'select' && (
                                                <div className="form-floating mb-1">
                                                    <Field className="form-control mt-2 mb-2" name={field.name} id="floatingInput" as="select">
                                                        <option value="">Select</option>
                                                        {field.options.map(option => (
                                                            <option key={option} value={option}>{option}</option>
                                                        ))}
                                                    </Field>
                                                    <label htmlFor="floatingInput">{field.label}</label>

                                                </div>

                                            )}
                                            {field.type === 'radio' &&
                                                <>
                                                    <h6>{field.label}</h6>
                                                    {field.options.map(option => (
                                                        <>
                                                            <label key={option}>
                                                                <Field className="form-check-input" type="radio" name={field.name} value={option} />
                                                                &nbsp;&nbsp;{option}
                                                            </label>&nbsp;&nbsp;</>
                                                    ))}
                                                </>
                                            }
                                            {field.type === 'checkbox' &&
                                                <>
                                                    <h6>{field.label}</h6>
                                                    {field.options.map(option => (
                                                        <><label key={option}>
                                                            <Field className="form-check-input" type="checkbox" name={field.name} value={option} />
                                                            &nbsp;&nbsp;{option}
                                                        </label>&nbsp;&nbsp;</>
                                                    ))}
                                                </>

                                            }
                                            <ErrorMessage className='text-danger' name={field.name} component="div" />
                                        </div>
                                    ))}
                                </div>
                                <div className="d-flex justify-content-center mt-4 ">
                                    <button className='btn btn-success' type="submit">Submit</button>
                                </div>
                            </div>
                        </Form>
                    </Formik>
                </div>
            </div>
            <PageLoader text="Loading" visibility={pageLoader} />
        </div>
    )
}