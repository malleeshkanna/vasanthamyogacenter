import './Form.css';

export default function SuccessResponse() {
    return (
        <div className='container'>
            <div className="d-flex justify-content-center pt-3">
                <img src="./header-img.png" className='img-fluid' alt="" />
            </div>
            <div className='forms-container p-4 mt-5'>
                <h3>Your form has been successfully submitted! </h3>
                <p>Your response has been successfully received by Vasantham Yoga Center. We appreciate your time and effort. If you have any further questions or need assistance, please feel free to contact us. Have a wonderful day!

                </p>
            </div>
        </div>
    )
}