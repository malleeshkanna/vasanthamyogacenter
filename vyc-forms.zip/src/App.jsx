import { useState } from 'react'
import './App.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.min.js';
import 'react-toastify/dist/ReactToastify.css';

import FormHome from './components/FormHome';
import SuccessResponse from './components/SuccessResponse';
import { Routes ,Route } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';

function App() {

  return (
    <div className='vycform-bg'>
      <Routes>
        <Route path="/:id" element={<FormHome/>}></Route>
        <Route path="/success" element={<SuccessResponse/>}></Route>
      </Routes>
      <ToastContainer />
      
    </div>
  )
}

export default App
