import axios from "axios";

export default function ApiService() {
    const baseurl = "http://192.168.29.21/vasanthamyogacenter/public";

    return {
        postMethod: async (url, formData) => {
            try {
                const response = await axios.post(baseurl + url, formData, {
                    headers: {
                        'Content-Type': 'multipart/form-data',
                    }
                });
                return response.data;
            } catch (error) {
                return error;
            }
        },
        getMethod: async (url) => {
            try {
                const response = await axios.get(baseurl + url);
                return response.data;
            } catch (error) {
                return error;
            }
        },
        getImages: (url) => {
            return baseurl + "/storage/" + url
        }
    }
}
