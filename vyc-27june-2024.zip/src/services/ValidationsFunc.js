export default function ValidationsFunc() {
    return {
        onlyAlphabets: function (input) {
            input.target.value = input.target.value.replace(/[^a-zA-Z\s]/g, '');
        },
        onlyNumbers:function(input){
            input.target.value = input.target.value.replace(/[^0-9]/g, '');
        }
    }
}