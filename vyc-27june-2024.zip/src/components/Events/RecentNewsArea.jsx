export default function RecentNewsArea() {
    return (
        <div className="mt-5">
            <div className="recent-news">
                <div className="recent-news-header p-3">
                    <h4>Recent Events</h4>
                </div>
                <div className="recent-news-body p-3">
                    <div className="event-box p-2">
                        <div className="row">
                            <div className="col-4">
                                <img src="/home/parallax-bg.webp" alt="" />
                            </div>
                            <div className="col-8">
                                <p>
                                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quidem, repellat!
                                </p>
                                <a href="" className="text-center">Click Here</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}