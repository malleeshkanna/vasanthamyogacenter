import './FormsList.css';
import PageLoder from '../../Services/PageLoder';
import ApiService from '../../Services/ApiService';
import { useEffect, useState } from 'react';
import ToasterService from '../../Services/ToasterService';
import { useNavigate } from 'react-router-dom';

export default function FormsList() {
    const [FormsListLoader, SetFormsListLoader] = useState(false);
    const [FormsData, SetFormsData] = useState([]);
    const [LastPage, SetLastPage] = useState(1);
    const [currentPage, SetCurrentPage] = useState(1);
    const [TotalCount, SetTotalCount] = useState(0);
    const [FormsTempData, SetFormsTempData] = useState([]);
    const navigate = useNavigate();
    const [copied, setCopied] = useState(false);
    const formsWebsiteLink = "https://forms.vasanthamyogacenter.com/";

    useEffect(() => {
        initQueries(currentPage);
    }, [])

    async function initQueries(pgno) {
        SetFormsListLoader(true);
        const res = await ApiService().postMethod('/forms/getall-forms?page=' + pgno);
        console.log(res);
        SetFormsData(res.data.data)
        SetFormsListLoader(false);
        SetLastPage(res.data.last_page);
        SetCurrentPage(res.data.current_page);
        SetTotalCount(res.data.total)
    }

    function paginate(pgno) {
        SetCurrentPage(pgno);
        initQueries(pgno);
    }

    async function DeleteFormsData() {
        const res = await ApiService().postMethod('/forms/delete', { id: FormsTempData.id });
        if (res.status) {
            ToasterService().notifySuccess(res.message);
            initQueries();
        } else {
            ToasterService().notifyError(res.message);
        }
    }

    return (
        <>
            <div className="container mt-4">
                <h3 className='text-center'>Form Responses</h3>
                <div className="formlist-container p-4 mt-4">
                    <div className="row">
                        {FormsData.length != 0 ?
                            FormsData.map((data, i) => (
                                <div className="col-md-6 col-lg-4 mt-3" key={i}>
                                    <div className='query-card p-3'>
                                        <h4>{data.formname}</h4>
                                        <span>{data.description}</span><br />
                                        <i className="fa-regular fa-globe mt-3"></i>&nbsp;<a target='_blank' href={formsWebsiteLink + data.link}>Open Form</a>
                                        <a className='btn ms-3' href={"https://api.whatsapp.com/send?text="+formsWebsiteLink + data.link} > <i className='fa fa-share'></i> Share</a>
                                        <div className="row mt-3">
                                            <div className="col-6">
                                                <button onClick={() => navigate("/form-responses/" + data.link)} className="btn btn-primary w-100"><i className='fa fa-eye'></i>&nbsp;&nbsp;View</button>
                                            </div>
                                            <div className="col-6">
                                                <button data-bs-toggle="modal" onClick={() => SetFormsTempData(data)} data-bs-target="#deleteContactConfirm" className="btn btn-danger w-100"><i className='fa fa-trash'></i>&nbsp;&nbsp;Delete</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )) :
                            <>
                                <h1 className='text-center'>
                                    <i className="fa-solid fa-file-slash"></i>
                                </h1>
                                <h3 className='text-center mt-3'>No Data Available</h3>
                            </>
                        }

                    </div>
                </div>
                {TotalCount > 10 ?
                    <div className="d-flex justify-content-between mt-3 ">
                        <div>
                            <button className='submit-btn' disabled={currentPage == 1} onClick={() => { paginate(currentPage - 1) }} ><i className="fa-solid fa-chevrons-left"></i>&nbsp;Prev</button>
                        </div>
                        <div>
                            <button className='submit-btn' disabled={currentPage == LastPage} onClick={() => { paginate(currentPage + 1) }} >Next&nbsp;<i className="fa-solid fa-chevrons-right"></i></button>
                        </div>
                    </div> : null
                }

            </div>

            {/* Delete Modal */}

            <div className="modal fade" id="deleteContactConfirm" tabIndex="-1" aria-labelledby="deleteContactConfirmLabel" aria-hidden="true">
                <div className="modal-dialog  modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="deleteContactConfirmLabel">Delete Confirmation</h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div className="modal-body">
                            Are you sure want to delete ?
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-success" onClick={() => DeleteFormsData()} data-bs-dismiss="modal">Yes</button>
                            <button type="button" className="btn btn-danger" data-bs-dismiss="modal">No</button>
                        </div>
                    </div>
                </div>
            </div>
            <PageLoder text="Loading" visibility={FormsListLoader} />
        </>

    )
}