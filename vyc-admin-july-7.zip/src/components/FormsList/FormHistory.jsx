import './FormsList.css';
import PageLoder from '../../Services/PageLoder';
import ApiService from '../../Services/ApiService';
import { useEffect, useState } from 'react';
import ToasterService from '../../Services/ToasterService';
import { useNavigate, useParams } from 'react-router-dom';

export default function FormsList() {
    const [FormsHistoryListLoader, SetFormsHistoryListLoader] = useState(false);
    const [FormHistory, SetFormHistory] = useState([]);
    const [FormHistory2, SetFormHistory2] = useState([]);
    const [LastPage, SetLastPage] = useState(1);
    const [currentPage, SetCurrentPage] = useState(1);
    const [TotalCount, SetTotalCount] = useState(0);
    const [FormsHistoryTempData, SetFormsHistoryTempData] = useState([]);
    const [ViewFormResponse, SetFormResponse] = useState([]);
    const { id } = useParams();

    useEffect(() => {
        initQueries(currentPage);
    }, [])

    async function initQueries(pgno) {
        SetFormsHistoryListLoader(true);
        const res = await ApiService().getMethod('/forms/get-form-response?page=' + pgno + "&link=" + id);
        SetFormHistory(res.data.data);
        SetFormHistory2(res.data2);
        SetFormsHistoryListLoader(false);
        SetLastPage(res.data.last_page);
        SetCurrentPage(res.data.current_page);
        SetTotalCount(res.data.total)
    }

    function paginate(pgno) {
        SetCurrentPage(pgno);
        initQueries(pgno);
    }

    async function DeleteFormHistory() {
        const res = await ApiService().postMethod('/forms/delete-form-response', { id: FormsHistoryTempData.id });
        if (res.status) {
            ToasterService().notifySuccess(res.message);
            initQueries();
        } else {
            ToasterService().notifyError(res.message);
        }
    }

    function setTempData(data) {
        SetFormsHistoryTempData(data)
        const jsonData = JSON.parse(data.formresponse)
        SetFormResponse(jsonData)
    }

    return (
        <>
            <div className="container mt-4">
                <h3 className='text-center'>{FormHistory2.formname} - Responses</h3>
                <div className="formlist-container p-4 mt-4">
                    <div className="row">
                        {FormHistory.length != 0 ?
                            FormHistory.map((data, i) => (
                                <div className="col-md-6 col-lg-4 mt-3" key={i}>
                                    <div className='query-card p-3'>
                                        <h5>Response - #{data.id}</h5>
                                        <div className="row mt-3">
                                            <div className="col-6">
                                                <button data-bs-toggle="modal" className="btn btn-primary w-100" onClick={() => setTempData(data)} data-bs-target="#ViewResponse"><i className='fa fa-eye'></i>&nbsp;&nbsp;View</button>
                                            </div>
                                            <div className="col-6">
                                                <button data-bs-toggle="modal" onClick={() => SetFormsHistoryTempData(data)} data-bs-target="#deleteContactConfirm" className="btn btn-danger w-100"><i className='fa fa-trash'></i>&nbsp;&nbsp;Delete</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )) :
                            <>
                                <h1 className='text-center'>
                                    <i className="fa-solid fa-file-slash"></i>
                                </h1>
                                <h3 className='text-center mt-3'>No Data Available</h3>
                            </>
                        }

                    </div>
                </div>
                {TotalCount > 10 ?
                    <div className="d-flex justify-content-between mt-3 ">
                        <div>
                            <button className='submit-btn' disabled={currentPage == 1} onClick={() => { paginate(currentPage - 1) }} ><i className="fa-solid fa-chevrons-left"></i>&nbsp;Prev</button>
                        </div>
                        <div>
                            <button className='submit-btn' disabled={currentPage == LastPage} onClick={() => { paginate(currentPage + 1) }} >Next&nbsp;<i className="fa-solid fa-chevrons-right"></i></button>
                        </div>
                    </div> : null
                }

            </div>

            {/* View Response */}

            <div className="modal fade" id="ViewResponse" tabIndex="-1" aria-labelledby="ViewResponseLabel" aria-hidden="true">
                <div className="modal-dialog  modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="ViewResponseLabel">Response - #{FormsHistoryTempData.id}</h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div className="modal-body">
                            <table className='table table-striped'>
                                <tbody>
                                    {Object.keys(ViewFormResponse).map((key) => (
                                        <tr key={key}>
                                            <th>{key}</th>
                                            <th>{ViewFormResponse[key]}</th>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>

                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-danger" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Delete Modal */}

            <div className="modal fade" id="deleteContactConfirm" tabIndex="-1" aria-labelledby="deleteContactConfirmLabel" aria-hidden="true">
                <div className="modal-dialog  modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="deleteContactConfirmLabel">Delete Confirmation</h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div className="modal-body">
                            Are you sure want to delete ?
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-success" onClick={() => DeleteFormHistory()} data-bs-dismiss="modal">Yes</button>
                            <button type="button" className="btn btn-danger" data-bs-dismiss="modal">No</button>
                        </div>
                    </div>
                </div>
            </div>


            <PageLoder text="Loading" visibility={FormsHistoryListLoader} />
        </>

    )
}