import './Events.css';
import { Formik, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import ToasterService from '../../Services/ToasterService';
import ApiService from '../../Services/ApiService';
import PageLoder from '../../Services/PageLoder';
import { useEffect, useState } from 'react';
import EventsList from './EventsList';

export default function Events() {

    const [submitBtn,setSubmitBtn]=useState(false);

    const validationSchema = Yup.object().shape({
        heading: Yup.string()
            .min(3, 'Heading must be at least 3 characters')
            .required('Heading is required'),
        event_date: Yup.string()
            .required('Event Date is required'),
        location: Yup.string()
            .min(3, 'Location must be at least 3 characters')
            .required('Location is required'),
        description: Yup.string()
            .min(3, 'Description must be at least 3 characters')
            .required("Description is Required"),
        mainImage: Yup.mixed().required('Main image is required')
    });

    const formValues = {
        heading: '',
        event_date: '',
        location: '',
        description: '',
        mainImage: null
    }

    async function submitEvent(data){
        setSubmitBtn(true);
        data.event_url=convertToPlainText(data.heading);
        const res=await ApiService().postMethod('/events/insert',data);
        setSubmitBtn(false);
        if(res.status){
            ToasterService().notifySuccess(res.message);
            window.location.reload();
        }else{
            ToasterService().notifyWarning(res.message)
        }
    }

    function convertToPlainText(str) {
        return str
          .toLowerCase() // Convert to lowercase
          .replace(/[^a-z0-9\s-]/g, '') // Remove special characters except spaces and hyphens
          .trim() // Trim leading/trailing spaces
          .replace(/[\s-]+/g, '-') // Replace spaces and hyphens with a single hyphen
          .replace(/^-+|-+$/g, ''); // Remove leading/trailing hyphens
      }
      
    return (
        <div className="container mt-4">
            <h3 className='text-center'>Add Event</h3>
            <div className="event-form-container p-4 mt-4">
                <Formik
                    initialValues={formValues}
                    validationSchema={validationSchema}
                    onSubmit={(values, actions) => {
                        submitEvent(values);
                        actions.setSubmitting(false);
                    }}
                >
                    {({ handleSubmit, setFieldValue, handleChange, handleBlur, values }) => (
                        <form onSubmit={handleSubmit}>
                            <div className="row">
                                <div className="col-lg-4">
                                    <div className="form-floating mb-1">
                                        <Field className="form-control mt-2 mb-2" onChange={handleChange} onBlur={handleBlur} value={values.heading} type="text" name="heading" id="floatingInput" placeholder="Eg., Yoga Day" />
                                        <label htmlFor="floatingInput">Heading</label>
                                    </div>
                                    <ErrorMessage name="heading" className="text-danger" component="div" />
                                </div>
                                <div className="col-lg-4">
                                    <div className="form-floating mb-1">
                                        <Field className="form-control mt-2 mb-2" onChange={handleChange} onBlur={handleBlur} value={values.event_date} type="date" name="event_date" id="floatingInput" placeholder="Eg., 2024-06-24" />
                                        <label htmlFor="floatingInput">Event Date</label>
                                    </div>
                                    <ErrorMessage name="event_date" className="text-danger" component="div" />
                                </div>
                                <div className="col-lg-4">
                                    <div className="form-floating mb-1">
                                        <Field className="form-control mt-2 mb-2" onChange={handleChange} onBlur={handleBlur} value={values.location} type="text" name="location" id="floatingInput" placeholder="Eg., Salem" />
                                        <label htmlFor="floatingInput">Location</label>
                                    </div>
                                    <ErrorMessage name="location" className="text-danger" component="div" />
                                </div>
                                <div className="col-lg-4">
                                    <div className="form-floating mb-1">
                                        <input className="form-control mt-2 mb-2" onChange={(event) => setFieldValue("mainImage", event.currentTarget.files[0])} type="file" name="mainImage" id="floatingInput" />
                                        <label htmlFor="floatingInput">Main Image</label>
                                    </div>
                                    <ErrorMessage name="mainImage" className="text-danger" component="div" />
                                </div>
                                <div className="col-lg-6">
                                    <div className="form-floating mb-1">
                                        <Field as="textarea" className="form-control mt-2 mb-2" onChange={handleChange} onBlur={handleBlur} value={values.description} name="description" id="floatingInput" placeholder="Eg., Lorem Ipsum." />
                                        <label htmlFor="floatingInput">Description</label>
                                    </div>
                                    <ErrorMessage name="description" className="text-danger" component="div" />
                                </div>
                            </div>
                            <div className="d-flex justify-content-center mt-3">
                                <input type="submit" className="btn btn-success" value="Submit" />
                            </div>
                        </form>
                    )}
                </Formik>
            </div>
            <EventsList/>
            <PageLoder text="Updating" visibility={submitBtn}/>
        </div>
    )
}