import './Events.css';
import { useEffect, useState } from 'react';
import ApiService from '../../Services/ApiService';
import ToasterService from '../../Services/ToasterService';
import PageLoder from '../../Services/PageLoder';
import { Formik, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';

export default function EventsList() {
    const [EventsData, SetEvents] = useState([]);
    const [EventId, SetEventId] = useState(null);
    const [EventLoaderState, SetEventLoaderState] = useState(false);

    const [LastPage, SetLastPage] = useState(1);
    const [currentPage, SetCurrentPage] = useState(1);
    const [TotalCount, SetTotalCount] = useState(0);

    useEffect(() => {
        callEventsApi(currentPage);
    }, [])

    async function callEventsApi(pgno) {
        SetEventLoaderState(true)
        const res = await ApiService().getMethod('/events/showAll?page=' + pgno);
        console.log(res)
        SetEventLoaderState(false)
        if (res.status == false) {
            ToasterService().notifyError(res.message)
        } else {
            SetEvents(res.data)
            SetLastPage(res.last_page);
            SetCurrentPage(res.current_page);
            SetTotalCount(res.total)
        }
    }

    const EventUpdatevalidationSchema = Yup.object().shape({
        heading: Yup.string()
            .min(3, 'Heading must be at least 3 characters').required('Heading is required'),
        event_date: Yup.string().required('Event Date is required'),
        location: Yup.string().required('Location is required')
            .min(3, 'Location must be at least 3 characters'),
        description: Yup.string()
            .min(3, 'Description must be at least 3 characters').required('Description is required'),
        mainImage: Yup.mixed()
    });

    const [UpdateformValues, SetUpdateformValues] = useState({
        heading: '',
        event_date: '',
        location: '',
        description: '',
        mainImage: null
    })

    async function fetchDatausingId(id) {
        const res = await ApiService().postMethod('/events/single-event', { id: id });
        console.log(res)
        SetUpdateformValues(res.data)
        res.status ? null : ToasterService().notifyError(res.message);
    }

    async function updateEventData(data) {
        data.event_url = convertToPlainText(data.heading);
        const res = await ApiService().postMethod('/events/update', data);
        console.log(res)
        if (res.status) {
            ToasterService().notifySuccess(res.message);
            callEventsApi(currentPage);
        } else {
            ToasterService().notifyError(res.message)
        }
    }

    function paginate(pgno) {
        SetCurrentPage(pgno);
        callEventsApi(pgno);
    }

    async function deleteEvent(data) {
        SetEventLoaderState(true)
        const res = await ApiService().postMethod('/events/delete', { id: data.id, imgurl: data.imgurl });
        SetEventLoaderState(false)
        if (res.status) {
            callEventsApi(currentPage);
            ToasterService().notifySuccess(res.message)
        } else {
            ToasterService().notifyError(res.message)
        }
    }

    function convertToPlainText(str) {
        return str
            .toLowerCase() // Convert to lowercase
            .replace(/[^a-z0-9\s-]/g, '') // Remove special characters except spaces and hyphens
            .trim() // Trim leading/trailing spaces
            .replace(/[\s-]+/g, '-') // Replace spaces and hyphens with a single hyphen
            .replace(/^-+|-+$/g, ''); // Remove leading/trailing hyphens
    }

    return (
        <div className='events-form-container p-4 mt-4'>
            <h3 className='text-center'>Edit Events</h3>
            <div className='event-container mt-3 p-3'>
                <div className="row">
                    {EventsData.length != 0 ?
                        EventsData.map((event, i) => (
                            <div className="col-md-4 mt-3" key={i}>
                                <div className="p-3 events-imgs ">
                                    <img src={ApiService().getImages("events/" + event.imgurl)} alt="" />
                                    <h5 className='mt-3'>{event.heading}</h5>
                                    <div className="row mt-3">
                                        <div className="col-6">
                                            <button data-bs-toggle="modal" data-bs-target="#EditModal" onClick={() => fetchDatausingId(event.id)} className="btn btn-primary w-100"><i className="fa-regular fa-edit"></i>&nbsp;Edit</button>
                                        </div>
                                        <div className="col-6">
                                            <button data-bs-toggle="modal" data-bs-target="#DeleteConfirmDialog2" onClick={() => SetEventId(event)} className="btn btn-danger w-100"><i className="fa-regular fa-trash"></i>&nbsp;Delete</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )) :
                        <>
                            <h1 className='text-center'>
                                <i className="fa-solid fa-file-slash"></i>
                            </h1>
                            <h3 className='text-center mt-3'>No Data Available</h3>
                        </>
                    }
                </div>
             
            </div>
               {TotalCount > 10 ?
               <div className="d-flex justify-content-between mt-3 ">
                        <div>
                            <button className='submit-btn' disabled={currentPage == 1} onClick={() => { paginate(currentPage - 1) }} ><i className="fa-solid fa-chevrons-left"></i>&nbsp;Prev</button>
                        </div>
                        <div>
                            <button className='submit-btn' disabled={currentPage == LastPage} onClick={() => { paginate(currentPage + 1) }} >Next&nbsp;<i className="fa-solid fa-chevrons-right"></i></button>
                        </div>
                    </div> : null
                }
            <div className="modal fade" id="DeleteConfirmDialog2" tabIndex="-1" aria-labelledby="DeleteConfirmDialogLabel" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="DeleteConfirmDialogLabel">Confirmation</h5>
                        </div>
                        <div className="modal-body">
                            Are you sure want to delete ?
                        </div>
                        <div className="modal-footer">
                            <button type="button" data-bs-dismiss="modal" onClick={() => deleteEvent(EventId)} className="btn btn-danger">Yes</button>
                            <button type="button" className="btn btn-primary" data-bs-dismiss="modal">No</button>
                        </div>
                    </div>
                </div>
            </div>
            <div className="modal fade" id="EditModal" tabIndex="-1" aria-labelledby="DeleteConfirmDialogLabel" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="DeleteConfirmDialogLabel">Edit Event</h5>
                        </div>

                        <div className="modal-body">
                            <Formik
                                initialValues={UpdateformValues}
                                validationSchema={EventUpdatevalidationSchema}
                                enableReinitialize={true}
                                onSubmit={(values, actions) => {
                                    updateEventData(values);
                                    actions.setSubmitting(false);
                                }}
                            >
                                {({ handleSubmit, setFieldValue, handleChange, handleBlur, values }) => (
                                    <form onSubmit={handleSubmit}>
                                        <div className="row">
                                            <div className="col-lg-12">
                                                <div className="form-floating mb-1">
                                                    <Field className="form-control mt-2 mb-2" onChange={handleChange} onBlur={handleBlur} value={values.heading} type="text" name="heading" id="floatingInput" placeholder="Eg., Yoga Day" />
                                                    <label htmlFor="floatingInput">Heading</label>
                                                </div>
                                                <ErrorMessage name="heading" className="text-danger" component="div" />
                                            </div>
                                            <div className="col-lg-6">
                                                <div className="form-floating mb-1">
                                                    <Field className="form-control mt-2 mb-2" onChange={handleChange} onBlur={handleBlur} value={values.event_date} type="date" name="event_date" id="floatingInput" placeholder="Eg., 2024-06-24" />
                                                    <label htmlFor="floatingInput">Event Date</label>
                                                </div>
                                                <ErrorMessage name="event_date" className="text-danger" component="div" />
                                            </div>
                                            <div className="col-lg-6">
                                                <div className="form-floating mb-1">
                                                    <Field className="form-control mt-2 mb-2" onChange={handleChange} onBlur={handleBlur} value={values.location} type="text" name="location" id="floatingInput" placeholder="Eg., Salem" />
                                                    <label htmlFor="floatingInput">Location</label>
                                                </div>
                                                <ErrorMessage name="location" className="text-danger" component="div" />
                                            </div>
                                            <div className="col-lg-12">
                                                <div className="form-floating mb-1">
                                                    <input className="form-control mt-2 mb-2" onChange={(event) => setFieldValue("mainImage", event.currentTarget.files[0])} type="file" name="mainImage" id="floatingInput" />
                                                    <label htmlFor="floatingInput">Main Image</label>
                                                </div>
                                                <img src={ApiService().getImages('/events/' + values.imgurl)} className='img-fluid' alt="" />
                                                <ErrorMessage name="mainImage" className="text-danger" component="div" />
                                            </div>
                                            <div className="col-lg-12">
                                                <div className="form-floating mb-1">
                                                    <Field as="textarea" className="form-control mt-2 mb-2" onChange={handleChange} onBlur={handleBlur} value={values.description} name="description" id="floatingInput" placeholder="Eg., Lorem Ipsum." />
                                                    <label htmlFor="floatingInput">Description</label>
                                                </div>
                                                <ErrorMessage name="description" className="text-danger" component="div" />
                                            </div>
                                        </div>

                                        <div className="modal-footer">
                                            <input type="submit" className="btn btn-success" value="Submit" />

                                            {/* <button type="button" className="btn btn-primary" data-bs-dismiss="modal">Update</button> */}
                                            <button type="button" className="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                        </div>
                                    </form>
                                )}
                            </Formik>
                        </div>

                    </div>
                </div>
            </div>
            <PageLoder visibility={EventLoaderState} text="Loading" />
        </div>
    )
}