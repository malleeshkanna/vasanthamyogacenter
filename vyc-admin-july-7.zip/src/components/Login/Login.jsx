import './Login.css';
import { useNavigate } from 'react-router-dom';
import { Formik, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import ToasterService from '../../Services/ToasterService';
import ApiService from '../../Services/ApiService';
import PageLoder from '../../Services/PageLoder';
import { useState,useEffect } from 'react';
import axios from 'axios';

export default function Login() {
    const navigate = useNavigate();
    const [submitBtn, setSubmitBtn] = useState(false);

    useEffect(() => {
      if(localStorage.getItem('t$!9')!=null){
        navigate('/gallery')
      }
    }, [])
    

    const validationSchema = Yup.object().shape({
        email: Yup.string().email().required("Email is required"),
        password: Yup.string()
            .min(3, 'Password must be at least 6 characters')
            .required("Password is Required"),
    });

    async function ApiConnect(formData) {
        try {
            const response = await axios.post(ApiService().getBaseUrl() + "/user/login", formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                }
            });
            return response.data;
        } catch (error) {
            return error;
        }
    }

    async function loginnow(data) {
        setSubmitBtn(true);
        const res = await ApiConnect(data);
        setSubmitBtn(false);
        if (res.status) {
            ToasterService().notifySuccess(res.message);
            localStorage.setItem('t$!9', res.token);
            navigate('/gallery')
        } else {
            ToasterService().notifyWarning(res.message)
        }
    }

    const formValues = {
        email: '',
        password: '',
    }
    return (
        <div className='login-bg '>
            <div className="container p-4">
                <div className="row ">
                    <div className="col-md-6 logo-section">
                        <div className="logo-section d-flex align-items-center ">
                            <div>
                                <img src="/vyc-logo.png" alt="Vasantham Yaga Center" width="200" height="160" />
                                <h4 className='text-center mt-3 text-white'>ADMIN LOGIN</h4>
                            </div>

                        </div>
                    </div>
                    <div className="col-md-6 p-4 login-form">
                        <Formik
                            initialValues={formValues}
                            validationSchema={validationSchema}
                            onSubmit={(values, actions) => {
                                loginnow(values);
                                actions.setSubmitting(false);
                            }}
                        >
                            {({ handleSubmit, setFieldValue, handleChange, handleBlur, values }) => (
                                <form onSubmit={handleSubmit}>
                                    <div className="row">
                                        <div className="col-lg-12">
                                            <div className="form-floating mb-1">
                                                <Field className="form-control mt-2 mb-2" onChange={handleChange} onBlur={handleBlur} value={values.email} type="text" name="email" id="floatingInput" placeholder="Eg., someone@gmail.com" />
                                                <label htmlFor="floatingInput">Email</label>
                                            </div>
                                            <ErrorMessage name="email" className="text-danger" component="div" />
                                        </div>
                                        <div className="col-lg-12">
                                            <div className="form-floating mb-1">
                                                <Field className="form-control mt-2 mb-2" onChange={handleChange} onBlur={handleBlur} value={values.password} name="password" id="floatingInput" placeholder="Eg., " />
                                                <label htmlFor="floatingInput">Password</label>
                                            </div>
                                            <ErrorMessage name="password" className="text-danger" component="div" />
                                        </div>
                                    </div>
                                    <div className="d-flex justify-content-center mt-3">
                                        <input type="submit" disabled={submitBtn} className="btn btn-success" value="Submit" />
                                    </div>
                                </form>
                            )}
                        </Formik>
                    </div>
                </div>
            </div>
            <PageLoder text="Please Wait" visibility={submitBtn} />
        </div>
    )
}