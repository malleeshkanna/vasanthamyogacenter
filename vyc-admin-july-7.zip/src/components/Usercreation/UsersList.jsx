import { useEffect, useState } from 'react';
import ApiService from '../../Services/ApiService';
import ToasterService from '../../Services/ToasterService';
import PageLoder from '../../Services/PageLoder';
import { Formik, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';

export default function UsersList() {

    const [UserData, SetUser] = useState([]);
    const [AnnouncementId, SetUserId] = useState(null);
    const [EventLoaderState, SetEventLoaderState] = useState(false);

    useEffect(() => {
        callUserDataApi();
    }, [])

    async function callUserDataApi() {
        SetEventLoaderState(true)
        const res = await ApiService().postMethod('/user/list',{token:localStorage.getItem('t$!9')});
        console.log(res)
        SetEventLoaderState(false)
        if (res.status == false) {
            ToasterService().notifyError(res.message)
        } else {
            SetUser(res.data)
        }
    }

    const AnnouncementUpdatevalidationSchema = Yup.object().shape({
        name: Yup.string()
            .min(3, 'Name must be at least 3 characters')
            .required('Name is required'),
        email: Yup.string().email().required("Email is required"),
        password: Yup.string()
            .min(3, 'Password must be at least 6 characters'),
    });

    const [UpdateformValues, SetUpdateformValues] = useState({
        name: '',
        email: '',
        password: '',
    })

    async function fetchDatausingId(data) {
        console.log(data)
        const newObj = {
            name: data.name,
            email: data.email,
            id: data.id,
            password:''
        }
        console.log(newObj);
        SetUpdateformValues(newObj)
    }

    async function updateUserData(data) {
        console.log(data);
        const updateObj = {
            name: data.name,
            email: data.email,
            password: data.password,
            id: data.id
        }
        const res = await ApiService().postMethod('/user/update', updateObj);
        console.log(res)
        if (res.status) {
            ToasterService().notifySuccess(res.message);
            callUserDataApi();
        } else {
            ToasterService().notifyError(res.message)
        }
    }

    async function deleteEvent(data) {
        SetEventLoaderState(true)
        const res = await ApiService().postMethod('/user/delete', { id: data.id });
        SetEventLoaderState(false)
        if (res.status) {
            callUserDataApi();
            ToasterService().notifySuccess(res.message)
        } else {
            ToasterService().notifyError(res.message)
        }
    }

    return (
        <div className='register-form-container p-4 mt-4'>
            <h3 className='text-center'>Edit User</h3>
            <div className='register-container mt-3 p-3'>
                <div className="row p-3">
                    {UserData.length != 0 ?
                        UserData.map((event, i) => (
                            <div className="col-md-6 col-lg-4 m-3 register-bg" key={i}>
                                <div className="p-3">
                                    <h5 className='mt-3'>{event.name}</h5>
                                    <p className='mt-3 mb-3'>{event.email}</p>
                                    
                                    <div className="row mt-3">
                                        <div className="col-6">
                                            <button data-bs-toggle="modal" data-bs-target="#EditModal" onClick={() => fetchDatausingId(event)} className="btn btn-primary w-100"><i className="fa-regular fa-edit"></i>&nbsp;Edit</button>
                                        </div>
                                        <div className="col-6">
                                            <button data-bs-toggle="modal" disabled={UserData.length==1} data-bs-target="#DeleteConfirmDialog2" onClick={() => SetUserId(event)} className="btn btn-danger w-100"><i className="fa-regular fa-trash"></i>&nbsp;Delete</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )) :
                        <>
                            <h1 className='text-center'>
                                <i className="fa-solid fa-file-slash"></i>
                            </h1>
                            <h3 className='text-center mt-3'>No Data Available</h3>
                        </>
                    }
                </div>
            </div>
            <div className="modal fade" id="DeleteConfirmDialog2" tabIndex="-1" aria-labelledby="DeleteConfirmDialogLabel" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="DeleteConfirmDialogLabel">Confirmation</h5>
                        </div>
                        <div className="modal-body">
                            Are you sure want to delete ?
                        </div>
                        <div className="modal-footer">
                            <button type="button" data-bs-dismiss="modal" onClick={() => deleteEvent(AnnouncementId)} className="btn btn-danger">Yes</button>
                            <button type="button" className="btn btn-primary" data-bs-dismiss="modal">No</button>
                        </div>
                    </div>
                </div>
            </div>
            <div className="modal fade" id="EditModal" tabIndex="-1" aria-labelledby="DeleteConfirmDialogLabel" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="DeleteConfirmDialogLabel">Edit Event</h5>
                        </div>

                        <div className="modal-body">
                            <Formik
                                initialValues={UpdateformValues}
                                validationSchema={AnnouncementUpdatevalidationSchema}
                                enableReinitialize={true}
                                onSubmit={(values, actions) => {
                                    updateUserData(values);
                                    actions.setSubmitting(false);
                                }}
                            >
                                {({ handleSubmit, setFieldValue, handleChange, handleBlur, values }) => (
                                    <form onSubmit={handleSubmit}>
                                        <div className="row">
                                            <div className="col-lg-6">
                                                <div className="form-floating mb-1">
                                                    <Field className="form-control mt-2 mb-2" onChange={handleChange} onBlur={handleBlur} value={values.name} type="text" name="name" id="floatingInput" placeholder="Eg., Yoga Day" />
                                                    <label htmlFor="floatingInput">Name</label>
                                                </div>
                                                <ErrorMessage name="name" className="text-danger" component="div" />
                                            </div>
                                            <div className="col-lg-6">
                                                <div className="form-floating mb-1">
                                                    <Field className="form-control mt-2 mb-2" onChange={handleChange} onBlur={handleBlur} value={values.email} type="text" name="email" id="floatingInput" />
                                                    <label htmlFor="floatingInput">Email</label>
                                                </div>
                                                <ErrorMessage name="location" className="text-danger" component="div" />
                                            </div>
                                            <div className="col-lg-12">
                                                <div className="form-floating mb-1">
                                                    <Field as="textarea" className="form-control mt-2 mb-2" onChange={handleChange} onBlur={handleBlur} value={values.password} name="password" id="floatingInput" placeholder="Eg., Lorem Ipsum." />
                                                    <label htmlFor="floatingInput">Password</label>
                                                </div>
                                                <ErrorMessage name="password" className="text-danger" component="div" />
                                            </div>
                                        </div>

                                        <div className="modal-footer">
                                            <input type="submit" className="btn btn-success" value="Submit" />
                                            <button type="button" className="btn btn-danger" data-bs-dismiss="modal">Close</button>
                                        </div>
                                    </form>
                                )}
                            </Formik>
                        </div>

                    </div>
                </div>
            </div>
            <PageLoder visibility={EventLoaderState} text="Loading" />
        </div>
    )
}