import './Announcements.css';
import { Formik, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import ToasterService from '../../Services/ToasterService';
import ApiService from '../../Services/ApiService';
import PageLoder from '../../Services/PageLoder';
import { useState } from 'react';
import AnnouncementsList from './AnnouncementsList';

export default function Announcements() {

    const [submitBtn,setSubmitBtn]=useState(false);

    const validationSchema = Yup.object().shape({
        heading: Yup.string()
            .min(3, 'Heading must be at least 3 characters')
            .required('Heading is required'),
        link: Yup.string().url().nullable(),
        description: Yup.string()
            .min(3, 'Description must be at least 3 characters')
            .required("Description is Required"),
    });

    async function submitAnnouncement(data){
        setSubmitBtn(true);
        const res=await ApiService().postMethod('/announcement/insert',data);
        setSubmitBtn(false);
        if(res.status){
            ToasterService().notifySuccess(res.message);
            window.location.reload();
        }else{
            ToasterService().notifyWarning(res.message)
        }
    }

    const formValues = {
        heading: '',
        link: '',
        description: '',
    }

    return (
        <div className="container mt-4">
            <h3 className='text-center'>Add Announcements</h3>
            <div className="announcement-form-container p-4 mt-4">
            <Formik
                    initialValues={formValues}
                    validationSchema={validationSchema}
                    onSubmit={(values, actions) => {
                        submitAnnouncement(values);
                        actions.setSubmitting(false);
                    }}
                >
                    {({ handleSubmit, setFieldValue, handleChange, handleBlur, values }) => (
                        <form onSubmit={handleSubmit}>
                            <div className="row">
                                <div className="col-lg-4">
                                    <div className="form-floating mb-1">
                                        <Field className="form-control mt-2 mb-2" onChange={handleChange} onBlur={handleBlur} value={values.heading} type="text" name="heading" id="floatingInput" placeholder="Eg., Yoga Day" />
                                        <label htmlFor="floatingInput">Heading</label>
                                    </div>
                                    <ErrorMessage name="heading" className="text-danger" component="div" />
                                </div>
                                <div className="col-lg-4">
                                    <div className="form-floating mb-1">
                                        <Field className="form-control mt-2 mb-2" onChange={handleChange} onBlur={handleBlur} value={values.link} type="text" name="link" id="floatingInput" placeholder="Eg.," />
                                        <label htmlFor="floatingInput">Link</label>
                                    </div>
                                    <ErrorMessage name="link" className="text-danger" component="div" />
                                </div>
                                <div className="col-lg-4">
                                    <div className="form-floating mb-1">
                                        <Field as="textarea" className="form-control mt-2 mb-2" onChange={handleChange} onBlur={handleBlur} value={values.description} name="description" id="floatingInput" placeholder="Eg., Lorem Ipsum." />
                                        <label htmlFor="floatingInput">Description</label>
                                    </div>
                                    <ErrorMessage name="description" className="text-danger" component="div" />
                                </div>
                            </div>
                            <div className="d-flex justify-content-center mt-3">
                                <input type="submit" disabled={submitBtn} className="btn btn-success" value="Submit" />
                            </div>
                        </form>
                    )}
                </Formik>
            </div>
            <AnnouncementsList/>
            <PageLoder text={'Adding'} visibility={submitBtn}/>
        </div>
    )
}