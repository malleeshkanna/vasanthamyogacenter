import './Gallery.css';
import { useEffect, useState } from 'react';
import ApiService from '../../Services/ApiService';
import ToasterService from '../../Services/ToasterService';
import GalleryList from './GalleryList';
import PageLoder from '../../Services/PageLoder';

export default function Gallery() {
    const [files, setFiles] = useState([]);
    const [GalleryType,SetGalleryType]=useState(null);
    const [submitBtn,setSubmitBtn]=useState(false);

    const handleFileChange = (e) => {
        setFiles(e.target.files);
    };

    const handleUpload = async () => {
        const formData = new FormData();
        if (files.length != 0 && GalleryType!=null) {
            setSubmitBtn(true);
            for (let i = 0; i < files.length; i++) {
                formData.append('files[]', files[i]);
            }
            formData.append('type',GalleryType)
            const result = await ApiService().postMethod('/gallery/insert',formData);
            setSubmitBtn(false);
            result.status?ToasterService().notifySuccess(result.message):ToasterService().notifyWarning(result.message)
            setTimeout(() => {
                window.location.reload();
            }, 2000);
        }else{
            ToasterService().notifyWarning('Fill All Fields')
        }
    };

    return (
        <div className="container mt-4">
            <h3 className='text-center'>Update Gallery</h3>
            <div className="gallery-form-container p-4 mt-4">
                <div className="row">
                    <div className="col-md-5">
                        <label className='ms-2'>Upload Files</label>
                        <input type="file" multiple onChange={handleFileChange} className='form-control mt-2' />
                    </div>
                    <div className="col-md-4 mt-3 mt-md-0">
                        <label className='ms-2'>Select Type</label>
                        <select name="" id="" onChange={(e)=>SetGalleryType(e.target.value)} className="form-control mt-2">
                            <option value="">--Select--</option>
                            <option value="1">Asanas</option>
                            <option value="2">Infrastructure</option>
                        </select>
                    </div>
                    <div className="col-md-3">
                        <div className="d-flex justify-content-center mt-4">
                            <button onClick={handleUpload} disabled={submitBtn} className="btn btn-primary w-100 ">{submitBtn?'Please Wait...':'Submit'}</button>
                        </div>
                    </div>
                </div>
            </div>
            <GalleryList/>
            <PageLoder text="Updating" visibility={submitBtn}/>
        </div>
    )
}