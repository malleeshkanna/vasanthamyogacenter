import './Gallery.css';
import { useEffect, useState } from 'react';
import ApiService from '../../Services/ApiService';
import ToasterService from '../../Services/ToasterService';
import PageLoder from '../../Services/PageLoder';

export default function GalleryList() {
    const [galleryImages, SetGalleryImages] = useState([]);
    const [galleryId, SetGalleryId] = useState(null);
    const [LoaderState, SetLoaderState] = useState(false);

    const [LastPage, SetLastPage] = useState(1);
    const [currentPage, SetCurrentPage] = useState(1);
    const [TotalCount, SetTotalCount] = useState(0);

    useEffect(() => {
        callGalleryAPI(currentPage);
    }, [])

    async function callGalleryAPI(pgno) {
        SetLoaderState(true)
        const res = await ApiService().getMethod('/gallery/showAll?page='+pgno);
        console.log(res)
        SetLoaderState(false)
        if (res.status == false) {
            ToasterService().notifyError(res.message)

        } else {
            SetGalleryImages(res.data)
            SetLastPage(res.last_page);
            SetCurrentPage(res.current_page);
            SetTotalCount(res.total)
        }
    }

    async function deleteGallery(data) {
        SetLoaderState(true)
        const res = await ApiService().postMethod('/gallery/delete', {
            id: data.id, imgurl: data.imgurl
        });
        console.log(res)
        SetLoaderState(false)
        if (res.status) {
            callGalleryAPI(currentPage);
            ToasterService().notifySuccess(res.message)
        } else {
            ToasterService().notifyError(res.message)
        }
    }

    function paginate(pgno) {
        SetCurrentPage(pgno);
        callGalleryAPI(pgno);
    }

    return (
        <div className='gallery-form-container p-4 mt-4'>
            <h3 className='text-center'>Edit Gallery</h3>
            <div className='photo-container mt-3 p-3'>
                <div className="row">
                    {galleryImages.length != 0 ?
                        galleryImages.map((gallery, i) => (
                            <div className="col-md-4 mt-3" key={i}>
                                <div className="p-3 gallery-imgs ">
                                    <img src={ApiService().getImages("gallery/" + gallery.imgurl)} alt="" />
                                    <div className="row mt-3">
                                        <div className="col-12">
                                            <button data-bs-toggle="modal" data-bs-target="#DeleteConfirmDialog" onClick={() => SetGalleryId(gallery)} className="btn btn-danger w-100"><i className="fa-regular fa-trash"></i>&nbsp;Delete</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )) :
                        <>
                            <h1 className='text-center'>
                                <i className="fa-solid fa-file-slash"></i>
                            </h1>
                            <h3 className='text-center mt-3'>No Data Available</h3>
                        </>
                    }
                </div>
                {TotalCount > 10 ?
                    <div className="d-flex justify-content-between mt-3 ">
                        <div>
                            <button className='submit-btn' disabled={currentPage == 1} onClick={() => { paginate(currentPage - 1) }} ><i className="fa-solid fa-chevrons-left"></i>&nbsp;Prev</button>
                        </div>
                        <div>
                            <button className='submit-btn' disabled={currentPage == LastPage} onClick={() => { paginate(currentPage + 1) }} >Next&nbsp;<i className="fa-solid fa-chevrons-right"></i></button>
                        </div>
                    </div> : null
                } 
            </div>
            {/* <Modal */}
            <div className="modal fade" id="DeleteConfirmDialog" tabIndex="-1" aria-labelledby="DeleteConfirmDialogLabel" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="DeleteConfirmDialogLabel">Confirmation</h5>
                        </div>
                        <div className="modal-body">
                            Are you sure want to delete ?
                        </div>
                        <div className="modal-footer">
                            <button type="button" data-bs-dismiss="modal" onClick={() => deleteGallery(galleryId)} className="btn btn-danger">Yes</button>
                            <button type="button" className="btn btn-primary" data-bs-dismiss="modal">No</button>
                        </div>
                    </div>
                </div>
            </div>
            <PageLoder text="Please Wait" visibility={LoaderState} />
        </div>
    )
}