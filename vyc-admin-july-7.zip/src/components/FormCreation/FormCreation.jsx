import FormPreview from "./FormPreview";
import './FormCreation.css';
import { useState } from "react";
import ToasterService from '../../Services/ToasterService';
import ApiService from '../../Services/ApiService';
import PageLoder from '../../Services/PageLoder';

export default function FormCreation() {

    const [formName, SetFormName] = useState('');
    const [Description, SetDescription] = useState('');

    const [fieldType, SetFieldType] = useState('text');
    const [options, SetOptions] = useState([]);
    const [optionVal, SetOptionVal] = useState('');
    const [resetOptionTxt, SetResetTxtStatus] = useState(true);
    const [formData, setFormData] = useState([]);
    const [FormState, SetFormState] = useState(true);

    const [pageLoaderState,SetPageLoaderState]=useState(false);

    function addOptions() {
        if (optionVal != '') {
            SetOptions([...options, optionVal]);
            SetOptionVal('');
            SetResetTxtStatus(false);
            setTimeout(() => {
                SetResetTxtStatus(true);
            }, 10);
        }
    }

    function removeOption(index) {
        const newOptions = options.filter((_, i) => i != index);
        SetOptions(newOptions)
    }

    const convertFieldName = (name) => {
        return name
            .toLowerCase()
            .replace(/\s+/g, '_')       // Replace spaces with underscores
            .replace(/[^a-z0-9_]/g, '_');  // Replace all non-alphanumeric characters (except underscores) with underscores
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        const form = event.target;
        const data = new FormData(form);

        // Convert FormData to an object
        const formDataObject = Object.fromEntries(data.entries());

        const Formobj = {
            name: convertFieldName(formDataObject.label),
            label: formDataObject.label,
            type: formDataObject.type,
            validation: {
                required: formDataObject.required == "true",
            }
        }

        if (options.length != 0 && (fieldType == "select" || fieldType == "radio" || fieldType == "checkbox")) {
            Formobj['options'] = options;
        }

        if ((fieldType == "text" || fieldType == "number" || fieldType == "textarea")) {
            Formobj.validation['max'] = Number(formDataObject.max)
            Formobj.validation['min'] = 1
        }

        // Optionally, update the state if needed
        setFormData([...formData, Formobj]);
        SetOptions([]);
        SetFormState(false);
        SetFieldType('text');
        SetOptionVal('');

        setTimeout(() => {
            SetFormState(true);
        }, 10);

    };

    async function saveFormToDB() {
        if (Description != '' && formName != '' && formData.length != 0) {
            const fnlServeObj = {
                formname: formName,
                description: Description,
                formdata: JSON.stringify(formData)
            }
            SetPageLoaderState(true);
            const res =await ApiService().postMethod('/forms/create-form',fnlServeObj)
            SetPageLoaderState(false);
            console.log(res);
            if(res.status){
                ToasterService().notifySuccess(res.message);
                setTimeout(() => {
                    window.location.reload();
                }, 2000);
            }else{
                ToasterService().notifyWarning(res.message);
            }
            
        } else {
            ToasterService().notifyWarning("Please fill all the fields")
        }
    }

    return (
        <div className="p-4">
            <h3 className="text-center mb-4">Create Form</h3>
            <div className="container form-creation-container">
                <div className="px-3 pt-3">
                    <div className="row">
                        <div className="col-md-6 col-lg-6">
                            <div className="form-floating mb-1">
                                <input className="form-control mt-2 mb-2" onInput={(e) => SetFormName(e.target.value)} required type="text" id="floatingInput" placeholder="Eg.,John Doe" />
                                <label htmlFor="floatingInput">Form Name</label>
                            </div>
                        </div>
                        <div className="col-md-6 col-lg-6">
                            <div className="form-floating mb-1">
                                <textarea className="form-control mt-2 mb-2" onInput={(e) => SetDescription(e.target.value)} required type="text" id="floatingInput" placeholder="Eg.,John Doe" ></textarea>
                                <label htmlFor="floatingInput">Description</label>
                            </div>
                        </div>
                    </div>
                </div>

                {FormState &&
                    <form className="p-3" onSubmit={handleSubmit}>
                        <div className="row">
                            <div className="col-lg-4 col-md-6">
                                <div className="form-floating mb-1">
                                    <input className="form-control mt-2 mb-2" required name="label" type="text" id="floatingInput" placeholder="Eg.,John Doe" />
                                    <label htmlFor="floatingInput">Field Name</label>
                                </div>
                            </div>
                            <div className="col-lg-4 col-md-6">
                                <div className="form-floating mb-1">
                                    <select required className="form-control mt-2 mb-2" onChange={(e) => { SetFieldType(e.target.value) }} name="type" id="floatingInput" placeholder="Eg.,John Doe" >
                                        <option value="text">Short Answer</option>
                                        <option value="number">Number</option>
                                        <option value="select">Select</option>
                                        <option value="radio">Radio</option>
                                        <option value="checkbox">Checkbox</option>
                                        <option value="textarea">Long Answer</option>
                                    </select>
                                    <label htmlFor="floatingInput">Field Type</label>
                                </div>
                            </div>
                            <div className="col-lg-4 col-md-6">
                                <div className="form-floating mb-1">
                                    <select required className="form-control mt-2 mb-2" name="required" id="floatingInput" placeholder="Eg.,John Doe" >
                                        <option value="true">Yes</option>
                                        <option value="false">No</option>
                                    </select>
                                    <label htmlFor="floatingInput">Required </label>
                                </div>
                            </div>

                            {(fieldType == "text" || fieldType == "number") &&
                                <div className="col-lg-4 col-md-6">
                                    <div className="form-floating mb-1">
                                        <select required className="form-control mt-2 mb-2" name="max" id="floatingInput" placeholder="Eg.,John Doe" >
                                            <option value="2">2</option>
                                            <option value="10">10</option>
                                            <option value="15">15</option>
                                            <option value="30">30</option>
                                            <option value="50">50</option>
                                            <option value="100">100</option>
                                        </select>
                                        <label htmlFor="floatingInput">Max Length </label>
                                    </div>
                                </div>
                            }

                            {(fieldType == "textarea") &&
                                <div className="col-lg-4 col-md-6 ">
                                    <div className="form-floating mb-1">
                                        <select required className="form-control mt-2 mb-2" name="max" id="floatingInput" placeholder="Eg.,John Doe" >
                                            <option value="100">150</option>
                                            <option value="100">256</option>
                                        </select>
                                        <label htmlFor="floatingInput">Max Length </label>
                                    </div>
                                </div>
                            }

                            {(fieldType == "select" || fieldType == "radio" || fieldType == "checkbox") &&
                                <div className="col-lg-4 col-md-6 mt-3">
                                    <div className="options-header">
                                        <p className="mb-0">Add Options</p>
                                    </div>
                                    <div className="options-body p-3">
                                        {resetOptionTxt &&
                                            <div className="row">
                                                <div className="col-md-8">
                                                    <input type="text" onInput={(e) => { SetOptionVal(e.target.value) }} className="form-control" />
                                                </div>
                                                <div className="col-md-4">
                                                    <button type="button" onClick={() => addOptions()} className="btn btn-success w-100">Add</button>
                                                </div>
                                            </div>
                                        }
                                        <div className="mt-3">
                                            {options.map((el, i) => (
                                                <div className="option-values" key={i}>
                                                    <div className="d-flex justify-content-between">
                                                        <span className="mt-2">{el}</span>
                                                        <button type="button" onClick={() => removeOption(i)} className="btn btn-danger"><i className="fa fa-trash"></i></button>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            }
                            <div className="d-flex justify-content-center mt-4">
                                <button className="btn btn-primary">Submit</button>
                            </div>
                        </div>
                    </form>
                }

            </div>
            {formData.length != 0 &&
                <div className="container form-creation-container p-3">
                    <FormPreview formFields={formData} />
                    <div className="d-flex justify-content-center ">
                        <button disabled={pageLoaderState} onClick={() => saveFormToDB()} className="btn btn-success">Save Form</button>
                    </div>
                </div>
            }
            <PageLoder visibility={pageLoaderState} text="Saving" />
        </div>
    )
}