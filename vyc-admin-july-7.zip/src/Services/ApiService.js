import axios from "axios";
import ToasterService from "./ToasterService";

export default function ApiService() {
    const baseurl = "http://192.168.29.21/vasanthamyogacenter/public";
    
    const checkToken = async () => {
        try {
            const formData = { token: localStorage.getItem('t$!9') };
            const response = await axios.post(baseurl + "/user/check-token", formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                }
            });
            return response.data;
        } catch (error) {
            return error.response ? error.response.data : error.message;
        }
    };

    return {
        getBaseUrl:()=>{
            return baseurl;
        },
        postMethod: async (url, formData) => {
            try {
                const response = await axios.post(baseurl + url, formData, {
                    headers: {
                        'Content-Type': 'multipart/form-data',
                    }
                });
                const tokenresp=await checkToken()
                if(tokenresp.status && (!(new Date(tokenresp.data?.expires_at)<new Date()))){
                    return response.data;
                }else{
                    ToasterService().notifyError("Login is expired")
                    return {status:false,message:"Login is expired"}
                }
            } catch (error) {
                return {status:false,message:error};
            }
        },
        getMethod: async (url) => {
            try {
                const response = await axios.get(baseurl + url);
                const tokenresp=await checkToken()
                if(tokenresp.status && (!(new Date(tokenresp.data?.expires_at)<new Date()))){
                    return response.data;
                }else{
                    ToasterService().notifyError("Login is expired")
                    return {status:false,message:"Login is expired"}
                }
            } catch (error) {
                return {status:false,message:error};
            }
        },
        getImages:(url)=>{
            return baseurl+"/storage/"+url
        }
    }
}
