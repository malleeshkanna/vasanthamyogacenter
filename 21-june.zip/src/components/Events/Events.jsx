import Breadcrumb from "../../services/Breadcrumb";
import MainNewsArea from "./MainNewsArea";
import RecentNewsArea from "./RecentNewsArea";
import './Events.css'

export default function Events() {
    return (
        <div>
            <Breadcrumb img="/breadcrumb/events-bg.jpg" menu="Events" submenu={[{ link: 'Home', route: '/' }, { link: 'Events', route: '/events/0' }]} />
            <div className="p-3">
                <div className="container">
                    <div className="row">
                        <div className="col-md-8">
                            <MainNewsArea />
                        </div>
                        <div className="col-md-4">
                            <RecentNewsArea/>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    )
}

