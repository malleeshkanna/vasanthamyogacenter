export default function RecentNewsArea() {
    return (
        <div>
            <div className="recent-news">
                <div className="recent-news-header p-3">
                    <h4>Recent Events</h4>
                </div>
                <div className="recent-news-body">
                    <div className="event-box">

                    </div>
                </div>
            </div>
        </div>
    )
}