import Breadcrumb from "../../services/Breadcrumb";

import { CNav } from '@coreui/react'
import { CNavItem } from '@coreui/react'
import { CNavLink } from '@coreui/react'
import { CTabContent } from '@coreui/react'
import { CTabPane } from '@coreui/react'
import './Gallery.css';
import { useState } from "react";
import AsanasGallery from "./AsanasGallery";
import InfrastructureGallery from "./InfrastructureGallery";

export default function GalleryComp() {
    const [activeKey, setActiveKey] = useState(1)

    return <div>
        <Breadcrumb img="/breadcrumb/gallery-bg.jpg" menu="Gallery" submenu={[{ link: 'Home', route: '/' }, { link: 'Gallery', route: '/gallery' }]} />
        <div className="container-fluid">
            <div className="row">
                <div className="col-md-12 p-4">
                    <div className="gallery-section">
                        <div className="">
                            <CNav variant="tabs" role="tablist">
                                <CNavItem>
                                    <CNavLink
                                      
                                        active={activeKey === 1}
                                        onClick={() => setActiveKey(1)}
                                    >
                                        Asanas
                                    </CNavLink>
                                </CNavItem>
                                <CNavItem>
                                    <CNavLink
                                       
                                        active={activeKey === 2}
                                        onClick={() => setActiveKey(2)}
                                    >
                                        Infrastructure
                                    </CNavLink>
                                </CNavItem>
                            </CNav>
                            <CTabContent>
                                <CTabPane className="mt-3" role="tabpanel" aria-labelledby="home-tab" visible={activeKey === 1}>
                                    <AsanasGallery/>
                                </CTabPane>
                                <CTabPane role="tabpanel" className="mt-3" aria-labelledby="profile-tab" visible={activeKey === 2}>
                                    <InfrastructureGallery/>
                                </CTabPane>
                            </CTabContent>
                        </div>

                      
                    </div>
                </div>
            </div>
        </div>

    </div>

}