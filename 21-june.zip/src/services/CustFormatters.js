export default function CustFormatters(){
    return {
        dateFormatter:function(dateStr) {
            console.log(dateStr)
            const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        
            const date = new Date(dateStr);
            const day = date.getDate();
            const month = months[date.getMonth()];
            const year = date.getFullYear();
            const dayName = days[date.getDay()];
        
            return `${day}-${month}-${year} - ${dayName}`;
        }
    }
}