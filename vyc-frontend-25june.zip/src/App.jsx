import './App.css'
import '@coreui/coreui/dist/css/coreui.min.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

import { Route, Routes } from 'react-router-dom'
import ScrollToTop from "react-scroll-to-top";
import { lazy, Suspense } from 'react';

// Constants
import Navbar from './components/Navbar/Navbar'
import Footer from './components/Footer/Footer'
import PageLoader from './services/PageLoader';


// Lazy Components
const Home = lazy(() => import('./components/Home/Home'));
const Aboutus = lazy(() => import('./components/Aboutus/Aboutus'));
const GalleryComp = lazy(() => import('./components/Gallery/Gallery'));
const Events = lazy(() => import('./components/Events/Events'));
const Admission = lazy(() => import('./components/Admission/Admission'));
const Contactus = lazy(() => import('./components/Contactus/Contactus'));

function App() {

  return (
    <>
      <Navbar />
        <Suspense fallback={<PageLoader visibility={true} />}>
          <Routes>
            <Route path='/' element={<Home />} />
            <Route path='/aboutus' element={<Aboutus />} />
            <Route path='/gallery' element={<GalleryComp />} />
            <Route path='/events/:id' element={<Events />} />
            <Route path='/admission' element={<Admission />} />
            <Route path='/contactus' element={<Contactus />} />
          </Routes>
        </Suspense>
      <Footer />
      <ScrollToTop smooth className='scrolltop' />
    </>
  )
}

export default App
