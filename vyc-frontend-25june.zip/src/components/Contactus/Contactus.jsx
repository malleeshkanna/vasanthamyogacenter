import Breadcrumb from "../../services/Breadcrumb";
import './Contactus.css';
import React, { useState } from 'react';
import { Formik, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import ValidationsFunc from "../../services/ValidationsFunc";
import { Helmet } from "react-helmet-async";

export default function Contactus() {
    const validationSchema = Yup.object().shape({
        firstname: Yup.string()
            .min(3, 'Firstname must be at least 3 characters')
            .required('Firstname is required'),
        lastname: Yup.string()
            .min(3, 'Lastname must be at least 3 characters')
            .required('Lastname is required'),
        email: Yup.string().email(),
        phno: Yup.string().min(10, "Mobile number must be in 10 digit")
            .required("Mobile Number is required"),
        message: Yup.string()
            .required("Message is Required"),
        createdOn: Yup.date().default(() => new Date()),
    });

    const formValues = {
        firstname: '',
        lastname: '',
        email: '',
        phno: '',
        message: '',
    }

    return <div>
        <Breadcrumb img="/breadcrumb/aboutus-bg.webp" menu="Contact Us" submenu={[{ link: 'Home', route: '/' }, { link: 'Contact Us', route: '/contactus' }]} />
        <Helmet>
            <title>Contact Us - Vasantham Yoga Center</title>
            <meta name="description" content="Vasantham Yoga Center - Salem, Tamilnadu" />
            <meta name="keywords" content="best yoga center salem,best yoga center,yoga center" />
            <link rel="canonical" href="https://vasanthamyogacenter.com" />
        </Helmet>
        <div className="p-3 p-md-5 container">
            <div className="main-form-container">
                <div className="row">

                    <div className="col-md-6 order-2 d-flex align-items-center ">
                        <div>
                            <Formik
                                initialValues={formValues}
                                validationSchema={validationSchema}
                                onSubmit={(values, actions) => {
                                    console.log(values);
                                    actions.setSubmitting(false);
                                }}
                            >
                                {(data) => (
                                    <form className="p-4" onSubmit={data.handleSubmit}>

                                        <div className="row">
                                            <div className="col-lg-6 ">
                                                <div className="form-floating mb-1">
                                                    <Field className="form-control mt-2 mb-2" onInput={(e) => ValidationsFunc().onlyAlphabets(e)} onChange={data.handleChange} onBlur={data.handleBlur} value={data.values.firstname} type="text" name="firstname" id="floatingInput" placeholder="Eg., Karthick" />
                                                    <label htmlFor="floatingInput">Firstname</label>
                                                </div>
                                                <ErrorMessage name="firstname" className="text-danger" component="div" />
                                            </div>
                                            <div className="col-lg-6 mt-3 mt-md-0">
                                                <div className="form-floating mb-1">
                                                    <Field className="form-control mt-2 mb-2" onInput={(e) => ValidationsFunc().onlyAlphabets(e)} onChange={data.handleChange} onBlur={data.handleBlur} value={data.values.lastname} type="text" name="lastname" id="floatingInput" placeholder="Eg., Mahesh" />
                                                    <label htmlFor="floatingInput">Lastname</label>
                                                </div>
                                                <ErrorMessage name="lastname" className="text-danger" component="div" />
                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="col-lg-6 mt-3">
                                                <div className="form-floating mb-1">
                                                    <Field className="form-control mt-2 mb-2" type="text" onChange={data.handleChange} onBlur={data.handleBlur} value={data.values.email} name="email" id="floatingInput" placeholder="Eg., someone@gmail.com" />
                                                    <label htmlFor="floatingInput">Email</label>
                                                </div>
                                                <ErrorMessage name="email" className="text-danger" component="div" />
                                            </div>
                                            <div className="col-lg-6 mt-3">
                                                <div className="form-floating mb-1">
                                                    <Field className="form-control mt-2 mb-2" maxLength="10" onInput={(e) => ValidationsFunc().onlyNumbers(e)} type="text" onChange={data.handleChange} onBlur={data.handleBlur} value={data.values.phno} name="phno" id="floatingInput" placeholder="Eg., 1234567890" />
                                                    <label htmlFor="floatingInput">Mobile Number</label>
                                                </div>
                                                <ErrorMessage name="phno" className="text-danger" component="div" />
                                            </div>
                                        </div>
                                        <div className="row">
                                            <div className="col-md-12">
                                                <div className="form-floating mb-1">
                                                    <Field as="textarea" className="form-control mt-2 mb-2" row="10" onChange={data.handleChange} onBlur={data.handleBlur} value={data.values.address} name="message" id="floatingInput" placeholder="Eg., Annathanapatti, Salem" />
                                                    <label htmlFor="floatingInput">Message</label>
                                                </div>
                                                <ErrorMessage name="message" className="text-danger" component="div" />
                                            </div>
                                        </div>
                                        <div className="d-flex justify-content-center mt-3">
                                            <button type="submit" className='admission-btn'><i className="fa-light fa-check"></i>&nbsp;Submit</button>
                                        </div>
                                    </form>
                                )}
                            </Formik>
                        </div>

                    </div>
                    <div className="col-md-6 info-box d-flex align-items-center justify-content-center status-section mt-3 mt-md-0 ">
                        <div className="p-4">
                            <h4 className="text-center field-error ">Contact Us</h4>
                            {/* <h4 className="text-center field-error fw-bold ">Welcome to Vasantham Yoga Center</h4> */}
                            <div className="d-flex justify-content-center">
                                <img src="/common/vyc-logo.png" alt="" width="150" height="100" />
                            </div>
                            <div className="contact-field d-flex mt-3">
                                <i className="fa-solid fa-phone"></i>
                                <div className="ms-3">
                                    <label className="text-white">Phone</label><br />
                                    <a href="tel://+917092026756" className="field-error" target="_blank">+91 70920 26756</a>
                                </div>
                            </div>
                            <div className="contact-field d-flex mt-3">
                                <i className="fa-solid fa-envelope"></i>
                                <div className="ms-3">
                                    <label className="text-white">Email</label><br />
                                    <a href="mailto://vasanthamyogainfo@gmail.com" className="field-error" target="_blank">vasanthamyogainfo@gmail.com</a>
                                </div>
                            </div>
                            <div className="contact-field d-flex mt-3">
                                <i className="fa-solid fa-location-dot"></i>
                                <div className="ms-3">
                                    <label className="text-white">Address</label><br />
                                    <a href="https://maps.app.goo.gl/2S6VkhRfthCR4jMN6" className="field-error" target="_blank">Open in Google Map</a>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>
}