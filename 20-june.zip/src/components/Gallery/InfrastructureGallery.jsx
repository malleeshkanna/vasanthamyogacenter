
import LightGallery from 'lightgallery/react';
import lgZoom from 'lightgallery/plugins/zoom';
import lgShare from 'lightgallery/plugins/share';
import lgHash from 'lightgallery/plugins/hash';
import 'lightgallery/css/lightgallery.css';
import 'lightgallery/css/lightgallery-bundle.min.css';
import galleryfiles from './galleryfiles';
import { useEffect, useState } from "react";

export default function InfrastructureGallery() {
    const [imagesFiles, SetImageFiles] = useState([]);

    useEffect(() => {
        SetImageFiles(galleryfiles())
    }, [])

   return (<LightGallery
        elementClassNames={'masonry-gallery-demo'}
        plugins={[lgZoom, lgShare, lgHash]}
        speed={500}
    >
        <div className="grid-sizer"></div>
        {imagesFiles.map((el, index) => (
            <a key={index}
                data-lg-size="400-600-375, 600-900-480, 1600-2400"
                className="gallery-item"
                data-src={el.imgsrc}
                data-sub-html=""
            >
                <img
                    alt="layers of blue."
                    className=" images-effect"
                    width="300px" height="200px" style={{ objectFit: "cover" }}
                    src={el.imgsrc}
                />

            </a>
        ))}

    </LightGallery>)
}