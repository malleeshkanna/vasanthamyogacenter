import Breadcrumb from "../../services/Breadcrumb";

export default function Events(){
    return(
        <Breadcrumb img="/breadcrumb/aboutus-bg.webp" menu="Events" submenu={[{ link: 'Home', route: '/' }, { link: 'Events', route: '/events/0' }]} />

    )
}