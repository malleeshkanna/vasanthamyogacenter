import { Link } from 'react-router-dom';
import './Breadcrumb.css';

export default function Breadcrumb({ img, menu, submenu }) {
    return (
        <div className="breadcrumb-container">
            <img src={img} alt="Breadcrumb Background" className="image"></img>
            <h3 className="text">{menu}</h3>
            <div>
                {submenu.map((menu, index) => (
                    <span>
                        <Link to={menu.route}>&nbsp;{menu.link} </Link>/
                    </span>

                ))}
            </div>
        </div>
    )
}