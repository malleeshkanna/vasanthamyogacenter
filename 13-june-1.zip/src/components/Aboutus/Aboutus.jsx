import Breadcrumb from "../../services/Breadcrumb";
import './Aboutus.css';

export default function Aboutus() {
    return <div>
        <Breadcrumb img="/breadcrumb/aboutus-bg.webp" menu="About Us" submenu={[{ link: 'Home', route: '/' }, { link: 'About us', route: '/aboutus' }]} />
        <div className="aboutus-section">
            <div className="p-3">
                <p className="text-justify">
                    Welcome to <b>Vasantham Yoga Center</b>, where the ancient art of yoga is revitalized for the modern world. Founded by Mr. Vishnu Bairavan, our center is dedicated to fostering physical health, mental clarity, and spiritual growth through comprehensive yoga training and practice.
                </p>
                <h3>Our Mission</h3>
                <p className="text-justify">
                    At Vasantham Yoga Center, our mission is to promote holistic wellness through the practice of yoga. We believe in the transformative power of yoga to improve physical health, mental clarity, and emotional balance. Our goal is to make yoga accessible to everyone, regardless of age, fitness level, or experience.
                </p>
            </div>
        </div>
    </div>
}