import Breadcrumb from "../../services/Breadcrumb";

export default function Gallery(){
    return <div>
                <Breadcrumb img="/breadcrumb/aboutus-bg.webp" menu="Gallery" submenu={[{link:'Home',route:'/'},{link:'Gallery',route:'/gallery'}]}  />
    </div>
}