import Breadcrumb from "../../services/Breadcrumb";

import LightGallery from 'lightgallery/react';
import lgZoom from 'lightgallery/plugins/zoom';
import lgShare from 'lightgallery/plugins/share';
import lgHash from 'lightgallery/plugins/hash';
import './Gallery.css';
import 'lightgallery/css/lightgallery.css';
import 'lightgallery/css/lightgallery-bundle.min.css';

import galleryfiles from './galleryfiles';
import { useEffect, useState } from "react";

export default function GalleryComp() {
    const [imagesFiles, SetImageFiles] = useState([]);
    useEffect(() => {
        SetImageFiles(galleryfiles())
    }, [])
    return <div>
        <Breadcrumb img="/breadcrumb/aboutus-bg.webp" menu="Gallery" submenu={[{ link: 'Home', route: '/' }, { link: 'Gallery', route: '/gallery' }]} />
        <div className="container-fluid">
            <div className="row">
                <div className="col-md-3 d-flex align-items-center justify-content-center  ">
                    <div className="d-block">
                        <input type="radio" className="btn-check" name="gallery_id" id="asanas" autoComplete="off" />
                        <label className="btn btn-outline-success" htmlFor="asanas">Asanas</label><br />
                        <div className="d-block">
                            <input type="radio" className="btn-check" name="gallery_id" id="infrastructure" autoComplete="off" />
                            <label className="btn btn-outline-success" htmlFor="infrastructure">Infrastructure</label><br />
                        </div>
                    </div><br /><br />

                </div>
                <div className="col-md-9 p-4">
                    <div className="gallery-section">
                        <LightGallery
                            elementClassNames={'masonry-gallery-demo'}
                            plugins={[lgZoom, lgShare, lgHash]}
                            speed={500}
                        >
                            <div className="grid-sizer"></div>
                            {imagesFiles.map((el, index) => (
                                <a key={index}
                                    data-lg-size="400-600-375, 600-900-480, 1600-2400"
                                    className="gallery-item"
                                    data-src={el.imgsrc}
                                    data-sub-html=""
                                >
                                    <img
                                        alt="layers of blue."
                                        className="p-2 images-effect"
                                        width="300px" height="200px" style={{ objectFit: "cover" }}
                                        src={el.imgsrc}
                                    />

                                </a>
                            ))}

                        </LightGallery>
                    </div>
                </div>
            </div>
        </div>

    </div>

}