import Slider from "react-slick";
import { useEffect, useState } from "react";
import ApiService from '../../services/ApiService';
import PageLoader from '../../services/PageLoader';
import { useNavigate } from "react-router-dom";

function AnnounceAndEvents() {

    const [loaderState,SetLoaderState]=useState(false);
    const [announcements, SetAnnouncement] = useState([]);
    const [RecentEvents, SetRecentEvents] = useState([]);
    const navigate = useNavigate();

    const VerticalSettings = {
        dots: true,
        infinite: true,
        slidesToShow: 2,
        slidesToScroll: 1,
        vertical: true,
        verticalSwiping: true,
        swipeToSlide: true,
        autoplay: true,
        pauseOnHover: true,
        speed: 500,
        autoplaySpeed: 4000,
    };

    var HorizontalSettings = {
        dots: true,
        infinite: true,
        slidesToShow: 2,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        pauseOnHover: true,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: true
                }
            },
            {
                breakpoint: 991,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    initialSlide: 2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    };

    useEffect(()=>{
        getAnnouncements();
        getRecentEvents();
    },[])

    async function getAnnouncements(){
        SetLoaderState(true);
        const res=await ApiService().getMethod('/announcement/getall')
        SetLoaderState(false);
        if(res.status){SetAnnouncement(res.data)}
    }

    async function getRecentEvents(){
        SetLoaderState(true);
        const res=await ApiService().getMethod('/events/eventpaginate?page=1&limit=3')
        SetLoaderState(false);
        console.log(res);
        if(res.status){SetRecentEvents(res.data.data)}
    }

    return <div className="events-and-announcement mt-4">
        <div className="container p-4">
            <div className="row">
                <div className="col-md-6 col-lg-4  ">
                    <div className="announcement">
                        <div className="announce-header">
                            <h3>Announcement</h3>
                        </div>
                        <div className="announcement-body">
                            {announcements.length!=0?
                             <Slider {...VerticalSettings}>
                             {announcements.map((ob, index) => (
                                 <div className="message" key={index}>
                                     <h5>{ob.heading}</h5>
                                     <p>{ob.description}</p>
                                     {ob.link!=null?
                                     <a href={ob.link} target="_blank">Click Here</a>:null}
                                 </div>
                             ))}

                         </Slider>:<div className="no-announcements">
                            <h4 className="text-center">No Announcements</h4>
                         </div>
                        }
                           
                        </div>
                    </div>
                </div>
                <div className="col-md-6 col-lg-8 mt-5 mt-md-0">
                    <div className="announcement">
                        <div className="announce-header">
                            <h3>Recent Events</h3>
                        </div>
                        <div className="announcement-body">
                            <Slider {...HorizontalSettings}>
                                {RecentEvents.map((event, index) => (
                                    <div className="p-3" key={index}>
                                        <div className="card " >
                                            <img className="card-img-top" src={ApiService().getImages(`/events/${event.imgurl}`)} alt="Card image cap"></img>
                                            <div className="card-body">
                                                <h5 className="card-title">{event.heading}</h5>
                                                <p className="card-text">{event.description?.length>60?event.description.slice(0,60)+"...":event.description}</p>
                                                <a onClick={()=>navigate('/events/'+event.event_url)} className="btn btn-success">Read More</a>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </Slider>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <PageLoader text="Loading" visibility={loaderState} />
    </div>
}

export default AnnounceAndEvents