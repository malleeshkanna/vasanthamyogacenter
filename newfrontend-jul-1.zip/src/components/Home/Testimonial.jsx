import { useEffect, useState } from "react";
import Slider from "react-slick";
import StartRating from "../../services/StartRating";
import ApiService from '../../services/ApiService';
import PageLoader from '../../services/PageLoader';

var settings = {
    dots: true,
    infinite: true,
    speed: 1500,
    slidesToShow: 3,
    slidesToScroll: 1,
    initialSlide: 0,
    autoplay: true,
    autoplaySpeed: 5000,
    cssEase: "linear",
    responsive: [
        {
            breakpoint: 1024,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 2,
                infinite: true,
                dots: false
            }
        },
        {
            breakpoint: 991,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 2,
                initialSlide: 2
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }
    ]
};


export default function Testimonial() {

    const [testimonials, Settestimonials] = useState([])
    const [loaderState,SetLoaderState]=useState(false);

    useEffect(()=>{
        fetchTestimonials();
    },[])

    async function fetchTestimonials(){
        SetLoaderState(true);
        const res=await ApiService().getMethod('/testimonials/getall');
        SetLoaderState(false);
        Settestimonials(res.data);
    }

    return <div className="testimonial-section pb-5">
        <div className="container">
            <div className="p-3">
                <h3 className="text-center">TESTIMONIAL</h3>
                <div className="mt-3">
                    <Slider {...settings}>
                        {testimonials?.map((val, index) => (
                            <div className="p-3" key={index}>
                                <div className="testimonial-card h-100">
                                    <h5>{val.name}</h5>
                                    <StartRating value={val.ratings} /><br />
                                    <div>
                                        <i>{val.message}</i>
                                    </div>
                                </div>
                            </div>
                        ))}

                    </Slider>
                </div>
            </div>
        </div>
        <PageLoader text="Loading" visibility={loaderState} />
    </div>
}