import { useEffect, useState } from "react";
import Breadcrumb from "../../services/Breadcrumb";
import './Events.css';
import ApiService from '../../services/ApiService';
import PageLoader from '../../services/PageLoader';
import { useNavigate } from "react-router-dom";

export default function AllEvents() {
    const [eventsList, SetEventList] = useState([]);
    const [NewsLoaderState, SetNewsLoaderState] = useState(false);
    const [LastPage, SetLastPage] = useState(1);
    const [currentPage, SetCurrentPage] = useState(1);
    const navigate=useNavigate();

    useEffect(() => {
        getAllEvents(1);
    }, [])
    async function getAllEvents(pgno) {
        SetNewsLoaderState(true)
        const res = await ApiService().getMethod(`/events/eventpaginate?page=${pgno}&limit=10`)
        SetNewsLoaderState(false)
        if (res.status) {
            const data = res.data.data;
            SetEventList(data);
            SetLastPage(res.totalEvents);
            SetCurrentPage(res.currentPage)
        }
    }

    function paginate(pgno) {
        getAllEvents(pgno);
        SetCurrentPage(pgno);
    }
    return (
        <div>
            <Breadcrumb img="/breadcrumb/events-bg.jpg" menu="Events" submenu={[{ link: 'Home', route: '/' }, { link: 'Events', route: '/events' }]} />
            <div className="container-fluid p-0">
                <div className="events-list-section p-3">
                    <div className="row">
                        {eventsList.map((data) => (
                            <div className="col-md-4 mt-3">
                                <div className="event-card">
                                    <img onClick={()=>{navigate('/events/'+data.event_url)}} src={ApiService().getImages('/events/' + data.imgurl)} alt="" />
                                    <div className="mt-3 p-2">
                                        <a onClick={()=>{navigate('/events/'+data.event_url)}} className="h5">{data.heading}</a>
                                        <p className="mt-3"><i class="fa-regular fa-calendar"></i>&nbsp;&nbsp;{data.event_date}</p>
                                        <p>{data.description?.length > 60 ? data.description.slice(0, 60) + '...' : data.description}</p>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>

                    {eventsList.length == 10 ?
                        <div className="d-flex justify-content-between mt-4">
                            <div>
                                <button className='btn btn-success' disabled={currentPage == 1} onClick={() => { paginate(currentPage - 1) }} ><i className="fa-solid fa-chevrons-left"></i>&nbsp;Prev</button>
                            </div>
                            <div>
                                <button className='btn btn-success' disabled={currentPage == LastPage} onClick={() => { paginate(currentPage + 1) }} >Next&nbsp;<i className="fa-solid fa-chevrons-right"></i></button>
                            </div>
                        </div> : null
                    }


                </div>
            </div>
            <PageLoader visibility={NewsLoaderState} />
        </div>
    )
}