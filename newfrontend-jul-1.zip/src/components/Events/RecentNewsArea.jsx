import { useState, useEffect } from "react"
import CustFormatters from "../../services/CustFormatters";
import { useParams, useNavigate } from 'react-router-dom';
import ApiService from '../../services/ApiService';
import PageLoader from '../../services/PageLoader';

export default function RecentNewsArea({ onTriggerPageChange }) {

    const [recentNews, SetRecentNews] = useState([]);
    const navigate=useNavigate();
    
    useEffect(() => {
        getRecentNews();
    }, [])

    async function getRecentNews() {
        const res = await ApiService().getMethod(`/events/eventpaginate?page1&limit=3`);
        console.log(res.data.data);
        SetRecentNews(res.data.data);
    }
    return (
        <div className="mt-5">
            <div className="recent-news ">
                <div className="recent-news-header p-3">
                    <h4>Recent Events</h4>
                </div>
                <div className="recent-news-body p-3">
                    {recentNews.map((news, i) => (
                        <div className="event-box p-2" key={i}>
                            <div className="row">
                                <div className="col-lg-6 col-md-12 col-sm-12">
                                    <img src={ApiService().getImages(`/events/${news.imgurl}`)} alt="" />
                                </div>
                                <div className="col-lg-6 col-md-12 col-sm-12">
                                    <a onClick={() => onTriggerPageChange(news.event_url)} className="mt-md-3 mt-3 mt-lg-0">
                                        {news.heading}
                                    </a>
                                    <p className="fw-bold mt-3">{CustFormatters().dateFormatterMini(news.event_date)}</p>
                                </div>
                            </div>
                        </div>
                    ))}
                    <button className="btn btn-success w-100 mt-3" onClick={()=>navigate('/events')}>Show More</button>

                </div>
            </div>
        </div>
    )
}