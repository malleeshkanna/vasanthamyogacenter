import { useState, useEffect,forwardRef, useImperativeHandle } from "react"
import CustFormatters from "../../services/CustFormatters";
import { CBadge } from '@coreui/react'
import { useParams,useNavigate  } from 'react-router-dom';
import ApiService from '../../services/ApiService';
import PageLoader from '../../services/PageLoader';

const MainNewsArea = forwardRef((props, ref) => {
    const [mainNews, setMainNews] = useState([]);
    const [NewsLoaderState,SetNewsLoaderState]=useState(false);

    const [LastPage,SetLastPage]=useState(1);
    const [currentPage,SetCurrentPage]=useState(1);


    const navigation =useNavigate ();

    const { id } = useParams();

    useImperativeHandle(ref, () => ({
        getLatestNewsInit,
    }));

    useEffect(() => {
        // getLatestNewsInit();
        if(isNaN(id)){
            getLatestNewsInit(id)
        }else{
            EventPaginate(id)
        }
    }, [])


    async function getLatestNewsInit(id){
        SetNewsLoaderState(true);
        const res = await ApiService().postMethod('/events/geteventbyurl',{url:id});
        SetNewsLoaderState(false);
        if(res.status){
            const data=res.data.data[0];
            navigation(`/events/${data.event_url}`);
            setMainNews(data);
            SetLastPage(res.totalEvents);
            SetCurrentPage(res.currentPage)
            props.SetEventLink({link:data.heading,route:'/events/'+data.event_url})
        }
    }

    async function EventPaginate(pgno){
        SetNewsLoaderState(true);
        const res = await ApiService().getMethod(`/events/eventpaginate?page=${pgno}&limit=1`);
        SetNewsLoaderState(false);
        const data=res.data.data[0];
        navigation(`/events/${data.event_url}`);
        setMainNews(data);
        SetLastPage(res.data.last_page);
        SetCurrentPage(res.data.current_page)
        props.SetEventLink({link:data.heading,route:'/events/'+data.event_url})
    }

    function shareOnWhatsapp(link){
        window.open("https://api.whatsapp.com/send?text=https://www.vasanthamyogacenter.com/events/" + link, '_blank');
    }

    function paginate(pgno){
        SetCurrentPage(pgno);
        EventPaginate(pgno);
        console.log(currentPage);
    }

    return (
        <div className="main-area-content">
            <h3 className="new-heading">{mainNews.heading}</h3>
            <div>
                <div>
                    <span className="details-color mt-1"><i className="fa-light fa-calendar"></i> &nbsp; {CustFormatters().dateFormatter(mainNews.event_date)}</span>
                    &nbsp;&nbsp;&nbsp;| &nbsp;&nbsp;<i className="fa-light fa-location-dot"></i>&nbsp; {mainNews.location} &nbsp;&nbsp;&nbsp;| &nbsp;&nbsp;<a onClick={()=>shareOnWhatsapp(mainNews.event_url)}><CBadge color="success"><i className="fa-brands fa-whatsapp"></i>&nbsp;Share on WhatsApp</CBadge> </a>
                </div>
            </div>
            <div className="mt-3">
                <img src={ApiService().getImages(`/events/${mainNews.imgurl}`)} className="news-img" alt="" />
                <p className="news-content mt-3">{mainNews.description}</p>
            </div>
            <div className="d-flex justify-content-between ">
                <div>
                    <button className='admission-btn' disabled={currentPage==1} onClick={() => { paginate(currentPage-1) }} ><i className="fa-solid fa-chevrons-left"></i>&nbsp;Prev</button>
                </div>
                <div>
                    <button className='admission-btn' disabled={currentPage==LastPage} onClick={() => { paginate(currentPage+1) }} >Next&nbsp;<i className="fa-solid fa-chevrons-right"></i></button>
                </div>
            </div>
            <PageLoader visibility={NewsLoaderState} />
        </div>
    )
})

export default  MainNewsArea