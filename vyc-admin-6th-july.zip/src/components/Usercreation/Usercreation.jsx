import './Usercreation.css';
import { Formik, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import ToasterService from '../../Services/ToasterService';
import ApiService from '../../Services/ApiService';
import PageLoder from '../../Services/PageLoder';
import { useState } from 'react';

export default function Usercreation() {

    const [submitBtn,setSubmitBtn]=useState(false);

    const validationSchema = Yup.object().shape({
        name: Yup.string()
            .min(3, 'Name must be at least 3 characters')
            .required('Name is required'),
        email: Yup.string().email().required("Email is required"),
        password: Yup.string()
            .min(3, 'Password must be at least 6 characters')
            .required("Password is Required"),
    });

    async function submitNewUser(data){
        setSubmitBtn(true);
        const res=await ApiService().postMethod('/user/create-new',data);
        setSubmitBtn(false);
        if(res.status){
            ToasterService().notifySuccess(res.message);
            window.location.reload();
        }else{
            ToasterService().notifyWarning(res.message)
        }
    }

    const formValues = {
        name: '',
        email: '',
        password: '',
    }

    return (
        <div className="container mt-4">
            <h3 className='text-center'>Add User</h3>
            <div className="register-form-container p-4 mt-4">
            <Formik
                    initialValues={formValues}
                    validationSchema={validationSchema}
                    onSubmit={(values, actions) => {
                        submitNewUser(values);
                        actions.setSubmitting(false);
                    }}
                >
                    {({ handleSubmit, setFieldValue, handleChange, handleBlur, values }) => (
                        <form onSubmit={handleSubmit}>
                            <div className="row">
                                <div className="col-lg-4">
                                    <div className="form-floating mb-1">
                                        <Field className="form-control mt-2 mb-2" onChange={handleChange} onBlur={handleBlur} value={values.name} type="text" name="name" id="floatingInput" placeholder="Eg., Karthik" />
                                        <label htmlFor="floatingInput">Name</label>
                                    </div>
                                    <ErrorMessage name="name" className="text-danger" component="div" />
                                </div>
                                <div className="col-lg-4">
                                    <div className="form-floating mb-1">
                                        <Field className="form-control mt-2 mb-2" onChange={handleChange} onBlur={handleBlur} value={values.email} type="text" name="email" id="floatingInput" placeholder="Eg., someone@gmail.com" />
                                        <label htmlFor="floatingInput">Email</label>
                                    </div>
                                    <ErrorMessage name="email" className="text-danger" component="div" />
                                </div>
                                <div className="col-lg-4">
                                    <div className="form-floating mb-1">
                                        <Field as="textarea" className="form-control mt-2 mb-2" onChange={handleChange} onBlur={handleBlur} value={values.password} name="password" id="floatingInput" placeholder="Eg., Lorem Ipsum." />
                                        <label htmlFor="floatingInput">Password</label>
                                    </div>
                                    <ErrorMessage name="password" className="text-danger" component="div" />
                                </div>
                            </div>
                            <div className="d-flex justify-content-center mt-3">
                                <input type="submit" disabled={submitBtn} className="btn btn-success" value="Submit" />
                            </div>
                        </form>
                    )}
                </Formik>
            </div>
            <PageLoder text={'Adding'} visibility={submitBtn}/>
        </div>
    )
}