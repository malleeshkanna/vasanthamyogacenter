
import LightGallery from 'lightgallery/react';
import lgZoom from 'lightgallery/plugins/zoom';
import lgShare from 'lightgallery/plugins/share';
import lgHash from 'lightgallery/plugins/hash';
import 'lightgallery/css/lightgallery.css';
import 'lightgallery/css/lightgallery-bundle.min.css';
import { useEffect, useState } from "react";
import ApiService from '../../services/ApiService';
import PageLoader from '../../services/PageLoader';

export default function AsanasGallery() {
    const [imagesFiles, SetImageFiles] = useState([]);
    const [LastPage,SetLastPage]=useState(1);
    const [currentPage,SetCurrentPage]=useState(1);
    const[AsanasLoaderState,SetAsanasLoaderState]=useState(false);
    useEffect(() => {
        setGalleryUsingAPI(1);
    }, [])

    async function setGalleryUsingAPI(pagenum) {
        let asanasArr = [];
        SetAsanasLoaderState(true);
        const res = await ApiService().getMethod(`/gallery/showAll?page=${pagenum}&type=1`);
        SetAsanasLoaderState(false);
        res.data.map((el) => asanasArr.push(ApiService().getImages(`/gallery/${el.imgurl}`)));
        SetLastPage(res.last_page);
        SetCurrentPage(res.current_page)
        SetImageFiles(asanasArr);
    }

    function paginate(pgno){
        SetCurrentPage(pgno);
        setGalleryUsingAPI(pgno);
    }

    return (

        <>
            <LightGallery
                elementClassNames={'masonry-gallery-demo'}
                plugins={[lgZoom, lgShare, lgHash]}
                speed={500}
            >
                <div className="grid-sizer"></div>
                {imagesFiles.map((el, index) => (
                    <a key={index}
                        data-lg-size="400-600-375, 600-900-480, 1600-2400"
                        className="gallery-item"
                        data-src={el}
                        data-sub-html=""
                    >
                        <img
                            alt="VYC - Asanas"
                            className="images-effect"
                            width="300px" height="200px" style={{ objectFit: "cover" }}
                            src={el}
                        />

                    </a>
                ))}

            </LightGallery>
            <div className="d-flex justify-content-between mt-4 ">
                <button className='admission-btn' disabled={currentPage==1} onClick={() => { paginate(currentPage-1) }} ><i className="fa-light fa-arrow-left"></i>&nbsp;Prev</button>
                <button className='admission-btn' disabled={currentPage==LastPage} onClick={() => { paginate(currentPage+1) }} >Next &nbsp;<i className="fa-light fa-arrow-right"></i></button>
            </div>
            <PageLoader visibility={AsanasLoaderState} />
        </>
    )
}