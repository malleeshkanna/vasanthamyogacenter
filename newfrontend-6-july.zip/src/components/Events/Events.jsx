import Breadcrumb from "../../services/Breadcrumb";
import MainNewsArea from "./MainNewsArea";
import RecentNewsArea from "./RecentNewsArea";
import './Events.css'
import { Helmet } from "react-helmet-async";
import React, { useEffect, useRef, useState } from 'react';

export default function Events() {
    const mainNewsAreaRef = useRef();
    const [eventLink,SetEventLink]=useState([]);

    const handlePageChange = (id) => {
        if (mainNewsAreaRef.current) {
            mainNewsAreaRef.current.getLatestNewsInit(id);
        }
    };

    useEffect(()=>{
        window.scrollTo(0,0)
    },[])

    return (
        <div>
            <Breadcrumb img="/breadcrumb/events-bg.jpg" menu="Events" submenu={[{ link: 'Home', route: '/' }, { link: 'Events', route: '/events' },{link:eventLink.link,route:eventLink.route}]} />
            <Helmet>
                <title>Events - Vasantham Yoga Center</title>
                <meta name="description" content="Vasantham Yoga Center - Salem, Tamilnadu" />
                <meta name="keywords" content="best yoga center salem,best yoga center,yoga center" />
                <link rel="canonical" href="https://vasanthamyogacenter.com/home" />
            </Helmet>
            <div className="p-3">
                <div className="container">
                    <div className="row">
                        <div className="col-md-8">
                            <MainNewsArea SetEventLink={SetEventLink} ref={mainNewsAreaRef}  />
                        </div>
                        <div className="col-md-4">
                            <RecentNewsArea onTriggerPageChange={handlePageChange} />
                        </div>
                    </div>
                </div>

            </div>
        </div>

    )
}

