export default function Gallery(){
    return <h3>Gallery</h3>
}