export default function Menubar({img,menu,submenu}){

}